///////////////////////////////////
// �������ƣ��¾���
// ���뻷����VC++ 6.0, EasyX_20120603b
// ��    �ߣ���֮��
// ������ʱ�䣺2012-8-31
///////////////////////////////////
#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

// ���ؿ⺯��
#pragma comment( lib, "msimg32.lib")
#pragma comment( lib, "winmm.lib")

///////////////�궨��///////////////
#define		UP     119	//����Ŀ���
#define		DOWN   115
#define		LEFT   97
#define		RIGHT  100

#define     TRUE   1
#define		FALSE  0
#define		ENTER  13
#define		SPACE  32

#define     WIN		1
#define		DIE		0

///////////////��������//////////////////
void InitGame();				//��ʼ����Ϸ
void LoadMusic();				//��������
void BackMusic();				//�������ֿ��ؿؼ�
void CurbMusic();				//��������
void GameRope();				//��Ϸ����
void BeginGame();				//��ʼ����
void MenuGame();				//��Ϸ���˵�
void Exit();					//�ر���Ϸ
void Manager();					//������ͼ
void Menu2();					//��Ϸ�еĲ˵�
void PetInfo();					//������Ϣ
void PetNature(int iNum);		//��������
int  DetectionHP();				//��⾫��HP
int  ChangePet();				//ս��ʱ��������
void AdvancePet(int iPetNum);	//����������������
void BeiBaoMenu();				//������Ʒ
void MenuChoose(int iNum);		//ѡ��
void UseRes(int iNum);			//ʹ����Ʒ

///////////��ͼ����///////////
int  FuSuiMap();
int  FuToNanMap();
int  NanNingMap();
int	 BeiHaiMap();
int  BeiToCrossMap();
int  WuZhouMap();
int  WuToFuMap();
int  CrossMap();
int  NanToBeiMap();
int  NanToLiuMap();
int  LiuZhouMap();
int  LiuToWuMap();
int  HomeMap();
void OtherHomeMap_1();
void OtherHomeMap_2();
void ClubMap_1();
void ClubMap_2();
void ShopMap();

void Shopping();				//���빺��
void PlayComputer();			//�������
int  GetPokNum(int iPokNum[]);  //ȡ��
void MovePok(int iFinalX,int iFinalY,IMAGE *imgBKPok);	//�˿����ƶ�

void KitShow(int iX,int iY);	//ս����ʾ����

void SetOthrePeopleXY(int iX,int iY);	//���������˵�����
void OthrePeopleMove(IMAGE *img,int iX,int iY,int iFlag1);	//�����������ƶ�

int  ClubZhanChang_1(int iAlwayPet);	//����ս��
void YeWaiZhanchang_1();				//Ұ��ս��
void Road_1(char *str);					//·�� ��ʾ
void Road_2(char *str);					//�Ի�
void MoveImage(IMAGE *imgbkNum);		//�Լ��ƶ�
void DeviceKBBuf();						//������̻���
void AlterScreen();						//��������


///////////////ȫ�ֱ���/////////////////
IMAGE imgOwe[4][3];		//����ͼƬ
IMAGE imgOtherPeople[4][4][3];
IMAGE imgBattle[8][4];
IMAGE imgPet[3];		//���Ǿ���
IMAGE imgPet1[40];		//��������
COLORREF BanClore=RGB(191,191,191);		//��ֹͨ��ɫֵ
COLORREF lkclore=RGB(254,123,1);		//����·��ɫֵ
COLORREF HomeClore=RGB(190,191,190);	//�������ɫֵ
COLORREF ShopClore=RGB(191,191,190);	//�����̵�ɫֵ
COLORREF ClubClore=RGB(191,190,190);	//�������ɫֵ
COLORREF RoadClore=RGB(128,64,0);		//����·��ɫֵ
COLORREF GouWuClore=RGB(190,191,191);	//���빺��ɫֵ
COLORREF ComputerClore=RGB(190,190,191);//�������ɫֵ

int  iOpenMusic=1;	//��Ǳ������ֿ���

char cWuPin[8][10]={"С����","�󻹵�","��Ѫ��","����","���","��¶","�ⶾ��","���Ѽ�"};
char cPetName[3][15]={"�ȿ���","���ٹ�","��˹"};
char cPetName1[40][15]={"����","������","��è","è�ϴ�","�ɴ�Ѽ","���","�𱬺�","���ٹ�","���ٹ�","�������","��Ӿ��","����","�¼���","����","����","����","����ѿ","�ڴ���","��ʳ��","���ˮĸ",
						"����ˮĸ","Сȭʯ","¡¡ʯ","¡¡��","С����","������","������","С�Ź�","����һ�Ź�","���Ѽ","����","С��ʨ","�׺�ʨ","����","������","���ױ�","��˹","��˹ͨ","����","����ʯ"};

//ö�ٵ�ͼ����
enum Map{HOME,FUSUI,FUtoNAN,NANNING,NANtoBEI,BEIHAI,CROSS_1,CROSS_2,WUZHOU,WUtoFU,NANtoLIU,LIUZHOU,LIUtoWU};

//ö����Ʒ����
enum WuPin{XIAOHUANDAN,DAHUANDAN,HUOXUEDAN,JIANGGUO,LINGCAO,YULU,JIEDUJI,HUANXINGJI};


struct People  //��������ṹ���귽��ṹ
{
	int iX,iY;		
	int iOldX,iOldY;
	int iDire;		//��������ƶ�����
	int iNewDire;	//������￪ʼ����
}Owe;

struct othrePeople	//�����˵�����
{
	int iX,iY;		//��������
	int iX1,iY1;	//�ƶ�����
	int iDire;		//ͼƬ����
	IMAGE imgbkNum;	//���︲�ǵı���
}OthrePeople[4];

struct Pet	//���徫������
{
	int  iNum;			//���
	int  iPH;			//��ǰ�У�ֵ
	int  iAlwayPH;		//PH��ֵ
	int  iGrade;		//�ȼ�
	int  iExp;			//����
	int  iAlwayExp;		//�������辭��
	int  iAtt;			//����
	int  iDef;			//����
};


struct Man	//��������
{
	int WuPin[8];		//���汳���е���Ʒ
	int iMoney;			//���
	struct Pet pet[3];	//����
	int iPetNum;		//������
}man;


////////////������//////////////
int main()
{
	// ������ͼ����
	initgraph(640,480);

	HWND hwnd = GetHWnd();
	SetWindowText(hwnd, "�¾���");

	InitGame();
	BeginGame();
	MenuGame();
	Manager();

	closegraph();
	return 0;
}

///////////////��ʼ��//////////////
void InitGame()
{
	srand((unsigned)time(NULL));	//������ֺ���

	IMAGE img,img1;
	IMAGE imgpet,imgpet1;
	IMAGE imgBat;

	int x=0,i,j,iNum=0;

	loadimage(&imgpet,"ͼƬ/����/����.bmp");
	loadimage(&imgpet1,"ͼƬ/����/�г�.bmp");
	loadimage(&img,"ͼƬ/����/�Լ�.bmp",90,160);
	loadimage(&img1,"ͼƬ/����/������.bmp",90,640);
	loadimage(&imgBat,"ͼƬ/ս������.bmp");

	man.iMoney=500;
	for(i=0;i<=8;i++)
		man.WuPin[i]=0;

	SetWorkingImage(&imgBat);
	for(x=0;x<8;x++)
		for(j=0;j<4;j++)
			getimage(&imgBattle[x][j],j*70,x*90,70,90);

	SetWorkingImage(&img);   //�ָ�����ͼƬ
	for(x=0;x<4;x++)
		for(j=0;j<3;j++)
			getimage(&imgOwe[x][j],j*30,x*40,30,40);

	SetWorkingImage(&img1);		//�ָ���������ͼƬ
	x=0;
	for(i=0;i<16;i++)
	{
		for(j=0;j<3;j++)
			getimage(&imgOtherPeople[x][iNum][j],j*30,i*40,30,40);
		if(++iNum>3)
		{
			iNum=0;
			x++;
		}
	}

	//�ָ��ͼƬ	
	SetWorkingImage(&imgpet);	
	iNum=0;
	for(x=0;x<3;x++)
			getimage(&imgPet[iNum++],x*84,0,84,90);

	SetWorkingImage(&imgpet1);
	iNum=0;
	for(x=0;x<8;x++)
		for(j=0;j<5;j++)
			getimage(&imgPet1[iNum++],j*84,x*90,84,90);

	SetWorkingImage();

	setbkmode(TRANSPARENT);//����������ɫΪ͸��
	setfont(20,0,"��Բ");	//������������
	setlinestyle(PS_SOLID,NULL,3);
	setcolor(BLACK);
	setbkcolor(WHITE);

	man.pet[1].iNum=2;
	man.pet[2].iNum=1;
	man.pet[0].iNum=0;
	man.iMoney=50;
	
	for(i=0;i<3;i++)
	{
		man.pet[i].iPH=20;
		man.pet[i].iAlwayPH=20;
		man.pet[i].iGrade=1;
		man.pet[i].iExp=0;
		man.pet[i].iAlwayExp=30;
		man.pet[i].iAtt=15;
		man.pet[i].iDef=10;
	}
	man.iPetNum=3;

	for(x=0;x<8;x++)
		man.WuPin[x]=0;

		man.WuPin[0]=5;		man.WuPin[7]=1;		man.WuPin[1]=1;
		man.WuPin[3]=1;		man.WuPin[5]=6;		man.WuPin[6]=1;

	LoadMusic();

}

//////////////////��������/////////////////
void LoadMusic()
{
	mciSendString("open ����/��������1.mp3 alias BackMusic1", NULL, 0, NULL); // ������
	mciSendString("open ����/��������2.mp3 alias BackMusic2", NULL, 0, NULL); 
	mciSendString("open ����/ս��������.mp3 alias BattleMusic", NULL, 0, NULL);
	mciSendString("open ����/������.wav alias OpenDoor", NULL, 0, NULL); 
	mciSendString("open ����/����.mp3 alias Battle", NULL, 0, NULL); 
	mciSendString("open ����/ʤ��.mp3 alias Win", NULL, 0, NULL); 
	mciSendString("open ����/ʧ��.mp3 alias Lose", NULL, 0, NULL); 
	mciSendString("open ����/������.wav alias Key", NULL, 0, NULL); 
	mciSendString("open ����/����.mp3 alias PlayPok", NULL, 0, NULL); 
	mciSendString("open ����/����.wav alias Advance", NULL, 0, NULL); 
	mciSendString("open ����/����.mp3 alias YuGuai", NULL, 0, NULL);

	mciSendString("setaudio BackMusic1 volume to 300",NULL,0,NULL);	//����������С
	mciSendString("setaudio BackMusic2 volume to 200",NULL,0,NULL);
	mciSendString("setaudio BattleMusic volume to 300",NULL,0,NULL);
	mciSendString("setaudio OpenDoor volume to 200",NULL,0,NULL);
	mciSendString("setaudio Battle volume to 500",NULL,0,NULL);
	mciSendString("setaudio Win volume to 300",NULL,0,NULL);
	mciSendString("setaudio Lose volume to 300",NULL,0,NULL);
	mciSendString("setaudio PlayPok volume to 150",NULL,0,NULL);
	mciSendString("setaudio YuGuai volume to 300",NULL,0,NULL);
}

///////////////////��Ϸ���˵�//////////////
void MenuGame()
{
	IMAGE imgMenuBK,imgMenu,imgMenu1,imgMusic;
	IMAGE imgMenubk;
	IMAGE img[4],imgMusic1[2];
	int   iY=1;
	int   i,iKey;

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC ;

	loadimage(&imgMenuBK,"ͼƬ/�˵�����.bmp");
	loadimage(&imgMenu,"ͼƬ/���˵�ѡ���.bmp");
	loadimage(&imgMenu1,"ͼƬ/���˵�ѡ���.bmp");
	loadimage(&imgMusic,"ͼƬ/���ֿ���.bmp");

	SetWorkingImage( &imgMenu1);
	for(i=0; i<4; i++)
		getimage(&img[i], 0, i*30, 140, 30);
	SetWorkingImage( &imgMusic);
	for(i=0; i<2; i++)
		getimage(&imgMusic1[i], 0, i*30, 30, 30);
	SetWorkingImage();

	mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������

	BeginBatchDraw();

	putimage(0,0,&imgMenuBK);
	srcDC = GetImageHDC( &imgMenu);
	TransparentBlt( dstDC, 307, 200, 113, 120, srcDC, 0, 0, 113, 120,  RGB(0,255,0));

	getimage(&imgMenubk,270,200,180,120);

BEGIN1:
	
	putimage(0,0,&imgMenuBK);			
	putimage(270,200,&imgMenubk);
	srcDC = GetImageHDC( &img[ iY-1]);
	TransparentBlt( dstDC, 280, 200 + (iY-1)*30, 140, 30, srcDC, 0, 0, 140, 30,  RGB(0,255,0));

	FlushBatchDraw();

	while( TRUE)
	{
		DeviceKBBuf();
		iKey = getch();

		if( iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

BEGIN2:
		switch( iKey)
		{
			case UP:
				if(--iY<1)
					iY=4;
				putimage(270,200,&imgMenubk);
				srcDC = GetImageHDC( &img[iY-1]);
				TransparentBlt( dstDC, 280, 200 + (iY-1)*30, 140, 30, srcDC, 0, 0, 140, 30,  RGB(0,255,0));
				FlushBatchDraw();

				break;

			case DOWN:
				if(++iY>4)
					iY=1;
				putimage(270,200,&imgMenubk);
				srcDC = GetImageHDC( &img[iY-1]);
				TransparentBlt( dstDC, 280, 200 + (iY-1)*30, 140, 30, srcDC, 0, 0, 140, 30,  RGB(0,255,0));
				FlushBatchDraw();

				break;

			case RIGHT:
				if( iY == 3)
				{
					srcDC = GetImageHDC( &imgMusic1[ iOpenMusic]);
					TransparentBlt( dstDC, 420, 260, 30, 30, srcDC, 0, 0, 30, 30,  RGB(0,255,0));
					FlushBatchDraw();

					while( TRUE)
					{	
						DeviceKBBuf();
						iKey = getch();

						if( iOpenMusic)
							mciSendString("play Key from 0", NULL, 0, NULL);

						switch( iKey)
						{
							case ENTER:
								if( iOpenMusic)
								{
									mciSendString("stop BackMusic2", NULL, 0, NULL);
									iOpenMusic=0;
								}
								else
								{
									mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������
									iOpenMusic=1;
								}

								srcDC = GetImageHDC( &imgMusic1[ iOpenMusic]);
								TransparentBlt( dstDC, 420, 260, 30, 30, srcDC, 0, 0, 30, 30,  RGB(0,255,0));
								FlushBatchDraw();

								break;

							case UP:
							case DOWN:
							case LEFT:
							case SPACE:
								goto BEGIN2;
								break;
						}
					}

				}
				break;

			case ENTER:
				switch( iY)
				{
					case 1:	//��ʼ��Ϸ
						if( iOpenMusic)
							mciSendString("stop BackMusic2", NULL, 0, NULL);
						EndBatchDraw();
						return;

					case 2:	//����˵��
						putimage(0,0,&imgMenuBK);
						GameRope();
						goto BEGIN1;

						break;

					case 4: //�˳���Ϸ
						EndBatchDraw();
						Exit();
						break;
				}

				break;

			case LEFT:
			case SPACE:
				putimage(270,200,&imgMenubk);
				srcDC = GetImageHDC( &img[iY-1]);
				TransparentBlt( dstDC, 280, 200 + (iY-1)*30, 140, 30, srcDC, 0, 0, 140, 30,  RGB(0,255,0));
				FlushBatchDraw();
				break;

			default :
				break;
		}

	}

	getch();

	return;
}

/////////////////����Ϸ/////////////////
void BeginGame()
{
	int i,j;
	int r,g,b;
	char chText[][8]={"�¾���","��֮��"};

	r=g=b=192;
	setfont(150,0,"��Բ");
	setbkcolor(RGB(192,192,192));

	BeginBatchDraw();
	cleardevice();
	for(i=0;i<2;i++)
	{
		for(j=0;j<190;j++)
		{
			setcolor( RGB( r-- , g--, b--));
			outtextxy(95,165,chText[i]);
			FlushBatchDraw();
			Sleep(20);
		}
		Sleep(1000);
		for( j=0;j<190;j++)
		{
			setcolor( RGB( r++ , g++, b++));
			outtextxy(95,165,chText[i]);
			FlushBatchDraw();
			Sleep(10);
		}
		Sleep(1000);
	}
	setfont(30,0,"����");
	for(j=0;j<190;j++)
	{
		setcolor( RGB( r , g--, b));
		outtextxy(50,225,"��ʾ���뽫�����л�ΪӢ��Сд����ģʽ");
		FlushBatchDraw();
		Sleep(10);
	}
	for(j=0;j<190;j++)
	{
		setcolor( RGB( r , g++, b));
		outtextxy(50,225,"��ʾ���뽫�����л�ΪӢ��Сд����ģʽ");
		FlushBatchDraw();
		Sleep(20);
	}

	EndBatchDraw();

	setfont(20,0,"��Բ");	//������������
	setcolor(BLACK);
	setbkcolor(WHITE);

	return ;
}

/////////////////��Ϸ����/////////////////
void GameRope()
{
	RECT Retc={10, 30, 630, 480};

	BeginBatchDraw();

	setfont(40, 0, "��Բ");	
	setcolor( RGB( 255, 0, 0));
	outtextxy(180, 5, "�¾�����Ϸ����");

	setfont(30, 0, "��Բ");
	drawtext("\n��Ϸ������\
		      \n  w �ϣ�Сд��\
			  \n  s ��\
			  \n  a ��\
			  \n  d ��\
			  \n  �ո��  ��Ϸ�е��þ���˵��뷵��\
			  \n  �س���  ѡ��\
			  \n\n��Ϸ��ʾ��\
			  \n  ��Ϸ�У���Ʒ�������̵�����й����ڱ����жԾ���ʹ����Ʒ��\
			  \n  ���Ѽ��ͽⶾ������ʹHPֵΪ0�ľ������ѹ�������ս����������Ʒ�����Ӳ�ͬ��HPֵ��", &Retc, DT_WORDBREAK);

	FlushBatchDraw();

	getch();
							
	if( iOpenMusic)					
		mciSendString("play Key from 0", NULL, 0, NULL);

	setfont(20,0,"��Բ");
	setcolor(BLACK);
	EndBatchDraw();

	return;
}
///////////////�������ֿ��ؿؼ�///////////
void BackMusic()
{
	IMAGE imgMusic,imgbk;
	IMAGE img[2];
	int   iKey;
	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC ;

	loadimage(&imgMusic,"ͼƬ/����/���ֿ���.bmp");

	SetWorkingImage(&imgMusic);
	getimage(&img[0],0,0,54,37);
	getimage(&img[1],0,38,54,37);
	SetWorkingImage();

	getimage(&imgbk,170,120,54,37);


	switch( iOpenMusic)
	{
		case 0:
			srcDC = GetImageHDC(&img[1]);
			TransparentBlt( dstDC, 170,120, 54, 37, srcDC, 0, 0, 54, 37,  RGB(0,255,0));	
			FlushBatchDraw();
			break;

		case 1:
			srcDC = GetImageHDC(&img[0]);
			TransparentBlt( dstDC, 170,120, 54, 37, srcDC, 0, 0, 54, 37,  RGB(0,255,0));	
			FlushBatchDraw();

			break;
	}

	while( TRUE)
	{
		iKey=getch();

		switch( iKey)
		{
			case ENTER:	
				mciSendString("play Key from 0", NULL, 0, NULL);

				switch( iOpenMusic)
				{
					case 0:
						iOpenMusic=1;
						srcDC = GetImageHDC(&img[0]);
						TransparentBlt( dstDC, 170,120, 54, 37, srcDC, 0, 0, 54, 37,  RGB(0,255,0));	
						FlushBatchDraw();
						break;

					case 1:
						iOpenMusic=0;
						srcDC = GetImageHDC(&img[1]);
						TransparentBlt( dstDC, 170,120, 54, 37, srcDC, 0, 0, 54, 37,  RGB(0,255,0));	
						FlushBatchDraw();

						break;
				}
				CurbMusic();

				break;

			case LEFT:
			case UP:
			case DOWN:
			case SPACE:
				if( iOpenMusic)
					mciSendString("play Key from 0", NULL, 0, NULL);

				putimage(170,120,&imgbk);
				return;

				break;

			default:
				break;
		}
	}

	return;
}

//////////////////��������//////////////
void CurbMusic()
{
	switch( iOpenMusic)
	{
		case 0:	
			mciSendString("stop BackMusic1", NULL, 0, NULL);
			mciSendString("stop BackMusic2", NULL, 0, NULL);

			break;
		case 1:
			mciSendString("play BackMusic2 repeat", NULL, 0, NULL); 

			break;
	}

	return;
}

//////////////////�رճ���////////////////
void Exit()
{
	mciSendString("close BackMusic1", NULL, 0, NULL);	//�ر�����
	mciSendString("close BackMusic2", NULL, 0, NULL);
	mciSendString("close BattleMusic", NULL, 0, NULL);
	mciSendString("close OpenDoor", NULL, 0, NULL);
	mciSendString("close Battle", NULL, 0, NULL);
	mciSendString("close Win", NULL, 0, NULL);
	mciSendString("close Lose", NULL, 0, NULL);
	mciSendString("close Key", NULL, 0, NULL);
	mciSendString("close PlayPok", NULL, 0, NULL);
	mciSendString("close Advance", NULL, 0, NULL);
	mciSendString("close YuGuai", NULL, 0, NULL);

	closegraph();
	exit(0);
}

//////////////////������̻���////////////
void DeviceKBBuf()
{
	while(kbhit())
		getch();
}

//////////////////��Ϸ�˵�/////////////
void Menu2()
{
	IMAGE imgNum,imgNumbk;//�˵�ͼƬ
	IMAGE img[4],imgNum1;
	int iKey,iY=1;

	loadimage(&imgNum,"ͼƬ/����/���˵�.bmp");
	loadimage(&imgNum1,"ͼƬ/����/���˵���.bmp");

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC = GetImageHDC(&imgNum);

	SetWorkingImage(&imgNum1);
	for(int i=0;i<4;i++)
		getimage(&img[i],0,i*40,100,40);
	SetWorkingImage();

	getimage(&imgNumbk,70, 40, 100, 160);

	if(iOpenMusic)
		mciSendString("play Key from 0", NULL, 0, NULL);

	TransparentBlt( dstDC, 70, 40, 100, 160, srcDC, 0, 0, 100, 160,  RGB(0,255,0));	//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();	// ʹ GDI ������Ч

	srcDC = GetImageHDC(&img[0]);
	TransparentBlt( dstDC, 70, 40, 100, 40, srcDC, 0, 0, 100, 40,  RGB(0,255,0));		
	FlushBatchDraw();

	while(TRUE)
	{	
		iKey=getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey)
		{
			case UP:
				srcDC = GetImageHDC(&imgNum);
				TransparentBlt( dstDC, 70, 40, 100, 160, srcDC, 0, 0, 100, 160,  RGB(0,255,0));	//����ɫ����Ϊ��ɫ 		

				if(--iY<1)
					iY=4;
				srcDC = GetImageHDC(&img[iY-1]);
				TransparentBlt( dstDC, 70, 40+(iY-1)*40, 100, 40, srcDC, 0, 0, 100, 40,  RGB(0,255,0));		
				FlushBatchDraw();

				break;

			case DOWN:
				srcDC = GetImageHDC(&imgNum);
				TransparentBlt( dstDC, 70, 40, 100, 160, srcDC, 0, 0, 100, 160,  RGB(0,255,0));		

				if(++iY>4)
					iY=1;
				srcDC = GetImageHDC(&img[iY-1]);
				TransparentBlt( dstDC, 70, 40+(iY-1)*40, 100, 40, srcDC, 0, 0, 100, 40,  RGB(0,255,0));	 		
				FlushBatchDraw();

				break;

			case SPACE:
				putimage(70,40,&imgNumbk);
				EndBatchDraw();
				return;
				break;

			case RIGHT:
				switch(iY)
				{
					case 1:
						PetInfo();//������Ϣ
						break;

					case 2:
						BeiBaoMenu();
						break;

					case 3:
						BackMusic();
						break;

					default :
						break;
				}
				break;

			case ENTER:
				switch(iY)
				{
					case 1:
						PetInfo();//������Ϣ
						break;

					case 2:
						BeiBaoMenu();
						break;

					case 3:
						BackMusic();
						break;

					case 4:	
						Exit();

						break;

					default :
						break;
				}

				break;

			default:
				break;
		}
	}

	return;
}

////////////////////������Ϣ/////////////
void PetInfo()
{
	IMAGE imgMenu,imgbkMenu;//����˵�
	IMAGE imgbkMenu1;
	int iKey;
	int iY=1,i;
	char cNum[10];


	loadimage(&imgMenu,"ͼƬ/����/��������ͼ/����˵�.bmp");

	getimage(&imgbkMenu,170, 40, 245, 270);

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC = GetImageHDC(&imgMenu);

	BeginBatchDraw();
	TransparentBlt( dstDC, 170, 40, 245, 270, srcDC, 0, 0, 245,270,  RGB(0,255,0));	 
	
	setcolor(YELLOW);

	for(i=0;i<3;i++)
		if(man.pet[i].iNum>=0)
		{
			srcDC = GetImageHDC(&imgPet[man.pet[i].iNum]);	//��ʾ����
			TransparentBlt( dstDC, 185,57+i*77, 84, 90, srcDC, 0, 0, 84,90,  RGB(0,255,0));
			outtextxy(275,70+i*77,cPetName[man.pet[i].iNum]);
			sprintf(cNum,"%d/%d",man.pet[i].iPH,man.pet[i].iAlwayPH);
			outtextxy(315,104+i*77,cNum);
		}

	getimage(&imgbkMenu1, 170, 40, 245, 270);

	setcolor(RGB(255,0,0));
	rectangle(188,59,386,130);

	FlushBatchDraw();

	while(TRUE)
	{
		iKey= getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey )	//ѡ����
		{
			case UP:
				if( man.iPetNum > --iY)
				{
					if(iY<1)
						iY=man.iPetNum;

					BeginBatchDraw();
					putimage(170, 40,&imgbkMenu1);
					rectangle(188,59+(iY-1)*77,386,53+iY*77);
					FlushBatchDraw();
				}
				break;

			case DOWN:

				if( ++iY>man.iPetNum)
					iY=1;
				if( man.iPetNum >=iY)
				{
					BeginBatchDraw();
					putimage(170, 40,&imgbkMenu1);
					rectangle(188,59+(iY-1)*77,386,53+iY*77);
					FlushBatchDraw();
				}

				break;

			case SPACE:
			case LEFT:
				setcolor(BLACK);
				putimage(170,40,&imgbkMenu);
				EndBatchDraw();
				return;

				break;

			case ENTER:
				PetNature(iY-1);

			default:
				break;
		}
	}

	setcolor(BLACK);
	putimage(170,40,&imgbkMenu);
	return;
}

////////////////��������//////////////////
void PetNature(int iNum)	//�ڼ�ֻ����
{
	IMAGE imgMenu,imgbkMenu;
	char cNum[10];
	loadimage(&imgMenu,"ͼƬ/����/��������ͼ/��������ͼ.bmp");

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC = GetImageHDC(&imgMenu);

	getimage(&imgbkMenu,170, 40, 245, 220);

	BeginBatchDraw();

	TransparentBlt( dstDC, 170, 40, 245, 220, srcDC, 0, 0, 245,220,  RGB(0,255,0));

	srcDC = GetImageHDC(&imgPet[man.pet[iNum].iNum]);
	TransparentBlt( dstDC, 182,48, 84, 90, srcDC, 0, 0, 84,90,  RGB(0,255,0));

	outtextxy(280,73,cPetName[man.pet[iNum].iNum]);//�������
	sprintf(cNum,"%d",man.pet[iNum].iGrade);
	outtextxy(260,128,cNum);
	sprintf(cNum,"%d/%d",man.pet[iNum].iExp,man.pet[iNum].iAlwayExp);
	outtextxy(260,158,cNum);
	sprintf(cNum,"%d",man.pet[iNum].iAtt);
	outtextxy(260,191,cNum);
	sprintf(cNum,"%d",man.pet[iNum].iDef);
	outtextxy(260,222,cNum);


	FlushBatchDraw();
	EndBatchDraw();

	Sleep(300);
	DeviceKBBuf();
	getch();

	if(iOpenMusic)
		mciSendString("play Key from 0", NULL, 0, NULL);

	putimage(170,40,&imgbkMenu);
	return;
}

///////////////////������Ʒ////////////////
void BeiBaoMenu()
{
	IMAGE imgNum,imgNumbk;
	IMAGE img[4],imgNum1;
	loadimage(&imgNum,"ͼƬ/����/�����˵�.bmp");
	getimage(&imgNumbk,170, 78, 132, 157);


	int iKey,iY=1;
	int i,iNum=1,iAlway=0;
	int iFlag=0;
	int iFlag_1=0; //���Ǳ�ǲ˵��ĵ�һ����Ʒ���

	char cNum[5];	

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC = GetImageHDC(&imgNum);

BEGIN:
	iY=1,iNum=1,iAlway=0,iFlag=0,iFlag_1=0;

	BeginBatchDraw();	
	TransparentBlt( dstDC, 170, 78, 132, 157, srcDC, 0, 0, 132, 157,  RGB(0,255,0));	//����ɫ����Ϊ��ɫ 		


	for(i=0;i<8;i++)//ͳ�ƹ�����Ʒ����
		if(man.WuPin[i]!=0)
			iAlway++;

	setcolor(YELLOW);

	for(i=0;i<8;i++)	//���
		if(man.WuPin[i]!=0)
		{
			iFlag++;
			outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
			sprintf(cNum,"%d",man.WuPin[i]);
			outtextxy(255, 85+(iFlag-1)*30, cNum);
			if(iFlag==5)
				break;
		}

	if( iAlway)
	{  
		setcolor(RGB(255,0,0));
		rectangle(176,85+(iY-1)*30,295,108+(iY-1)*30);
		setcolor(YELLOW);
	}

	FlushBatchDraw();

	while(TRUE)
	{
		iKey = getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey)
		{
			case UP:
				BeginBatchDraw();
				TransparentBlt( dstDC, 170, 78, 132, 157, srcDC, 0, 0, 132, 157,  RGB(0,255,0));		

				if(iAlway<=5 && iAlway>0)	//��Ʒ��������5��
				{
					if(--iY<1)
						iY = iAlway;

					iNum=iY;
					iFlag=0;

					for(i=0;i<8;i++)
						if(man.WuPin[i]!=0)
						{
							iFlag++;
							outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
							sprintf(cNum,"%d",man.WuPin[i]);
							outtextxy(255, 85+(iFlag-1)*30, cNum);
						}

					setcolor(RGB(255,0,0));
					rectangle(176,85+(iY-1)*30,295,108+(iY-1)*30);
					setcolor(YELLOW);
				}

				else if( iAlway > 5)	//��Ʒ�������5��
				{					
					if(--iNum<1)
					{
						iY=6;
						iNum=iAlway;
						iFlag_1=iAlway-5;
					}
					if( --iY<1)
						iY++;

					iFlag=0;

					if( iY==1)
					{
						iFlag_1=iNum-1;

						for(i=iFlag_1; ; i++)
							if( man.WuPin[i]!=0)
							{
								iFlag++;

								outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
								sprintf(cNum,"%d",man.WuPin[i]);
								outtextxy(255, 85+(iFlag-1)*30, cNum);

								if(iFlag==5)
									break;
							}

						setcolor(RGB(255,0,0));
						rectangle(176,85,295,108);
						setcolor(YELLOW);
					}

					else
					{		
						for(i=iFlag_1; ; i++)
							if(man.WuPin[i]!=0)
							{
								iFlag++;

								outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
								sprintf(cNum,"%d",man.WuPin[i]);
								outtextxy(255, 85+(iFlag-1)*30, cNum);

								if(iFlag==5)
									break;
							}

						setcolor(RGB(255,0,0));
						rectangle(176,85+(iY-1)*30,295,108+(iY-1)*30);
						setcolor(YELLOW);
					}
				}

				FlushBatchDraw();

				break;

			case DOWN:
				BeginBatchDraw();

				TransparentBlt( dstDC, 170, 78, 132, 157, srcDC, 0, 0, 132, 157,  RGB(0,255,0));		

				if(iAlway<=5 && iAlway>0)	//��Ʒ��������5��
				{
					if(++iY>iAlway)
						iY = 1;

					iNum=iY;
					iFlag=0;

					for(i=0;i<8;i++)
						if(man.WuPin[i]!=0)
						{
							iFlag++;
							outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
							sprintf(cNum,"%d",man.WuPin[i]);
							outtextxy(255, 85+(iFlag-1)*30, cNum);
						}

					setcolor(RGB(255,0,0));
					rectangle(176,85+(iY-1)*30,295,108+(iY-1)*30);
					setcolor(YELLOW);
				}

				else if( iAlway > 5)	//��Ʒ����5 �ֵ����
				{					
					if(++iNum>iAlway)
					{
						iY=0;
						iNum=1;
						iFlag_1=0;
					}
					if( ++iY>5)
						iY=5;

					iFlag=0;

					if( iY<5)
					{
						for(i=iFlag_1; ; i++)
							if( man.WuPin[i]!=0)
							{
								iFlag++;

								outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
								sprintf(cNum,"%d",man.WuPin[i]);
								outtextxy(255, 85+(iFlag-1)*30, cNum);

								if(iFlag==5)
									break;
							}

						setcolor(RGB(255,0,0));
						rectangle(176, 85+(iY-1)*30, 295, 108+(iY-1)*30);

						setcolor(YELLOW);
					}

					else
					{
						iFlag_1=iNum-5;	
						
						for(i=iFlag_1; ; i++)
							if(man.WuPin[i]!=0)
							{

								iFlag++;

								outtextxy(177, 85+(iFlag-1)*30, cWuPin[i]);
								sprintf(cNum,"%d",man.WuPin[i]);
								outtextxy(255, 85+(iFlag-1)*30, cNum);

								if(iFlag==5)
									break;
							}

						setcolor(RGB(255,0,0));
						rectangle(176,205,295,228);
						setcolor(YELLOW);
					}
				}

				FlushBatchDraw();

				break;

			case SPACE:
			case LEFT:
				EndBatchDraw();
				setcolor(BLACK);
				putimage(170, 78,&imgNumbk);
				return;

				break;

			case ENTER:
				if( iAlway)
				{
					iFlag=0;
					for(i=0;i<8;i++)	//������Ʒ���
						if(man.WuPin[i]!=0)
							if(++iFlag==iNum)
								break;

					MenuChoose(i);	//i�Ǳ�����ѡ�е���Ʒ���

					goto BEGIN;
				}

				break;

			default :
				break;
		}

	}

}

///////////////////�����˵�ѡ��///////////////
void MenuChoose(int iNum)	//iNum���ѡ�е���Ʒ���
{
	IMAGE imgNum,imgbkNum;
	int iKey,iY=1;

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC = GetImageHDC(&imgNum);

	loadimage(&imgNum,"ͼƬ/����/ѡ��.bmp");
	getimage(&imgbkNum, 192, 106, 85, 98);

	TransparentBlt(dstDC, 192, 106, 85, 98, srcDC, 0, 0, 85, 98, RGB(0,255,0));

	setcolor(RGB(255,0,0));
	outtextxy(209,112,"ʹ��");
	setcolor(YELLOW);
	outtextxy(209,144,"����");
	outtextxy(209,175,"����");
	FlushBatchDraw();

	while(TRUE)
	{
		iKey = getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey)
		{
			case UP:
				if(--iY<1)
					iY=3;

				TransparentBlt(dstDC, 192, 106, 85, 98, srcDC, 0, 0, 85, 98, RGB(0,255,0));
				switch(iY)
				{
					case 1:
						setcolor(RGB(255,0,0));
						outtextxy(209,112,"ʹ��");
						setcolor(YELLOW);
						outtextxy(209,144,"����");
						outtextxy(209,175,"����");
						FlushBatchDraw();

						break;

					case 2:
						setcolor(RGB(255,0,0));
						outtextxy(209,144,"����");
						setcolor(YELLOW);
						outtextxy(209,112,"ʹ��");
						outtextxy(209,175,"����");
						FlushBatchDraw();

						break;
					case 3:
						setcolor(RGB(255,0,0));
						outtextxy(209,175,"����");
						setcolor(YELLOW);
						outtextxy(209,112,"ʹ��");
						outtextxy(209,144,"����");
						FlushBatchDraw();

						break;
				}

				break;

			case DOWN:
				if(++iY>3)
					iY=1;

				TransparentBlt(dstDC, 192, 106, 85, 98, srcDC, 0, 0, 85, 98, RGB(0,255,0));

				switch(iY)
				{
					case 1:
						setcolor(RGB(255,0,0));
						outtextxy(209,112,"ʹ��");
						setcolor(YELLOW);
						outtextxy(209,144,"����");
						outtextxy(209,175,"����");
						FlushBatchDraw();

						break;

					case 2:
						setcolor(RGB(255,0,0));
						outtextxy(209,144,"����");
						setcolor(YELLOW);
						outtextxy(209,112,"ʹ��");
						outtextxy(209,175,"����");
						FlushBatchDraw();

						break;
					case 3:
						setcolor(RGB(255,0,0));
						outtextxy(209,175,"����");
						setcolor(YELLOW);
						outtextxy(209,112,"ʹ��");
						outtextxy(209,144,"����");
						FlushBatchDraw();

						break;
				}

				break;

			case ENTER:
				switch(iY)
				{
					case 1:	//ʹ��
						UseRes(iNum);
						setcolor(YELLOW);
						putimage(192,106,&imgbkNum);
						EndBatchDraw();
						return;

						break;
					case 2:	//����
						man.WuPin[iNum]--;

						setcolor(YELLOW);
						putimage(192,106,&imgbkNum);
						EndBatchDraw();
						return;

						break;

					case 3:	//����
						setcolor(YELLOW);
						putimage(192,106,&imgbkNum);
						EndBatchDraw();
						return;

						break;
				}

				break;

			default :
				break;
		}

	}

}

///////////////////ʹ����Ʒ////////////////
void UseRes(int iNum) //����Ϊʹ�õ���Ʒ���
{
	IMAGE imgMenu,imgbkMenu;//����˵�
	IMAGE imgbkMenu1;
	IMAGE imgHP;
	int iKey;
	int iY=1,i;

	char cNum[10];

	loadimage(&imgMenu,"ͼƬ/����/��������ͼ/����˵�.bmp");
	loadimage(&imgHP,"ͼƬ/����/��������ͼ/HPֵ����.bmp");

	getimage(&imgbkMenu, 170, 78, 245, 270);

BEGIN:

	HDC dstDC = GetImageHDC();  //��ȡ��ͼ�豸���
	HDC srcDC = GetImageHDC(&imgMenu);

	BeginBatchDraw();
	TransparentBlt( dstDC,  170, 78, 245, 270, srcDC, 0, 0, 245,270,  RGB(0,255,0));
	 		
	for(i=0;i<3;i++)
		if(man.pet[i].iNum>=0)
		{
			srcDC = GetImageHDC(&imgPet[man.pet[i].iNum]);	//��ʾ����
			TransparentBlt( dstDC, 185,95+i*77, 84, 90, srcDC, 0, 0, 84,90,  RGB(0,255,0));
			outtextxy(275,108+i*77,cPetName[man.pet[i].iNum]);
			sprintf(cNum,"%d/%d",man.pet[i].iPH,man.pet[i].iAlwayPH);
			outtextxy(315,142+i*77,cNum);
		}


	getimage(&imgbkMenu1, 170, 78, 245, 270);

	rectangle(188,96+(iY-1)*77,385,91+iY*77);

	FlushBatchDraw();
	

	if(man.WuPin[iNum]==0)//��Ʒ����
	{
		Sleep(500);
		setcolor(BLACK);
		FlushBatchDraw();
		putimage( 170, 78,&imgbkMenu);
		EndBatchDraw();
		return;
	}

	while(TRUE)
	{
		DeviceKBBuf();
		iKey= getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey )	//ѡ����ʹ����Ʒ
		{
			case UP:
				if( man.iPetNum > --iY)
				{
					if(iY<1)
						iY=man.iPetNum;

					BeginBatchDraw();
					putimage(170, 78,&imgbkMenu1);
					rectangle(188,96+(iY-1)*77,385,91+iY*77);
					FlushBatchDraw();
				}
				break;

			case DOWN:

				if( ++iY>man.iPetNum)
					iY=1;
				if( man.iPetNum >=iY)
				{
					BeginBatchDraw();
					putimage(170, 78,&imgbkMenu1);
					rectangle(188,96+(iY-1)*77,385,91+iY*77);
					FlushBatchDraw();
				}

				break;

			case SPACE:
			case LEFT:
				setcolor(BLACK);
				putimage( 170, 78,&imgbkMenu);
				EndBatchDraw();
				return;

				break;

			case ENTER:

				switch( iNum)
				{
					case XIAOHUANDAN:		//��ͬ����Ʒ�Ӳ�ͬ��HPֵ
						if(man.pet[iY-1].iPH<man.pet[iY-1].iAlwayPH && man.pet[iY-1].iPH) //����HP����0ʱ
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=10;
							if(man.pet[iY-1].iPH>man.pet[iY-1].iAlwayPH)
								man.pet[iY-1].iPH=man.pet[iY-1].iAlwayPH;
						}
						else if( man.pet[iY-1].iPH )
						{
							srcDC = GetImageHDC(&imgHP);	
							TransparentBlt( dstDC, 220,200, 150, 45, srcDC, 0, 0, 150,45,  RGB(0,255,0));
							FlushBatchDraw();	
							Sleep(500);
						}
						break;

					case DAHUANDAN:
						if(man.pet[iY-1].iPH<man.pet[iY-1].iAlwayPH && man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=15;
							if(man.pet[iY-1].iPH>man.pet[iY-1].iAlwayPH)
								man.pet[iY-1].iPH=man.pet[iY-1].iAlwayPH;
						}
						else if( man.pet[iY-1].iPH )
						{
							srcDC = GetImageHDC(&imgHP);
							TransparentBlt( dstDC, 220,200, 150, 45, srcDC, 0, 0, 150,45,  RGB(0,255,0));
							FlushBatchDraw();
							
							Sleep(500);
						}
						break;

					case HUOXUEDAN:
						if(man.pet[iY-1].iPH<man.pet[iY-1].iAlwayPH && man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=20;
							if(man.pet[iY-1].iPH>man.pet[iY-1].iAlwayPH)
								man.pet[iY-1].iPH=man.pet[iY-1].iAlwayPH;
						}
						else if( man.pet[iY-1].iPH )
						{
							srcDC = GetImageHDC(&imgHP);
							TransparentBlt( dstDC, 220,200, 150, 45, srcDC, 0, 0, 150,45,  RGB(0,255,0));
							FlushBatchDraw();	
							Sleep(500);
						}
						break;

					case JIANGGUO:
						if(man.pet[iY-1].iPH<man.pet[iY-1].iAlwayPH && man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=25;
							if(man.pet[iY-1].iPH>man.pet[iY-1].iAlwayPH)
								man.pet[iY-1].iPH=man.pet[iY-1].iAlwayPH;
						}
						else if( man.pet[iY-1].iPH )
						{
							srcDC = GetImageHDC(&imgHP);
							TransparentBlt( dstDC, 220,200, 150, 45, srcDC, 0, 0, 150,45,  RGB(0,255,0));
							FlushBatchDraw();	
							Sleep(500);
						}
						break;

					case LINGCAO:
						if(man.pet[iY-1].iPH<man.pet[iY-1].iAlwayPH && man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=30;
							if(man.pet[iY-1].iPH>man.pet[iY-1].iAlwayPH)
								man.pet[iY-1].iPH=man.pet[iY-1].iAlwayPH;
						}
						else if( man.pet[iY-1].iPH )
						{
							srcDC = GetImageHDC(&imgHP);
							TransparentBlt( dstDC, 220,200, 150, 45, srcDC, 0, 0, 150,45,  RGB(0,255,0));
							FlushBatchDraw();	
							Sleep(500);
						}
						break;

					case YULU:
				    	if(man.pet[iY-1].iPH<man.pet[iY-1].iAlwayPH && man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=35;
							if(man.pet[iY-1].iPH>man.pet[iY-1].iAlwayPH)
								man.pet[iY-1].iPH=man.pet[iY-1].iAlwayPH;
						}
						else if( man.pet[iY-1].iPH )
						{
							srcDC = GetImageHDC(&imgHP);
							TransparentBlt( dstDC, 220,200, 150, 45, srcDC, 0, 0, 150,45,  RGB(0,255,0));
							FlushBatchDraw();	
							Sleep(500);
						}
						break;

					case JIEDUJI:
						if(!man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=10;
						}

						break;
					case HUANXINGJI:
						if(!man.pet[iY-1].iPH)
						{
							man.WuPin[iNum]--;
							man.pet[iY-1].iPH+=10;
						}

						break;
				}

				goto BEGIN;

			default:
				break;
		}
	}

}

/////////////////�������е�ͼ//////////////
void Manager()
{
	int map=HOME; //��ǵ�ǰ��ͼ
	int j,r,g,b;
	Owe.iNewDire=3;
	Owe.iOldX= Owe.iX= 510;	//������������
	Owe.iOldY= Owe.iY= 85;

	setfont(30,0,"����");
	setbkcolor(RGB(192,192,192));
	r=g=b=192;

	BeginBatchDraw();
	cleardevice();
	for(j=0;j<190;j++)
	{
		setcolor( RGB( r , g--, b));
		outtextxy(95,165,"��ô�����ھͿ�ʼ���ð��֮�ðɣ�");
		FlushBatchDraw();
		Sleep(10);
	}
	Sleep(1000);
	for( j=0;j<190;j++)
	{
		setcolor( RGB( r , g++, b));
		outtextxy(95,165,"��ô�����ھͿ�ʼ���ð��֮�ðɣ�");
		FlushBatchDraw();
		Sleep(10);
	}
	Sleep(500);

	EndBatchDraw();

	setfont(20,0,"��Բ");	//������������
	setcolor(BLACK);
	setbkcolor(WHITE);

	AlterScreen();

	if( iOpenMusic)					
		mciSendString("play BackMusic1 repeat", NULL, 0, NULL);

	while(TRUE)
	{
		switch( map)
		{
			case HOME:
				map = HomeMap();
				break;

			case FUSUI:
				map = FuSuiMap();
				break;

			case FUtoNAN:
				map = FuToNanMap();
				break;

			case NANNING:
				map = NanNingMap();
				break;

			case NANtoBEI:
				map = NanToBeiMap();
				break;

			case BEIHAI:
				map = BeiHaiMap();
				break;

			case CROSS_1:
				map = BeiToCrossMap();
				break;

			case CROSS_2:
				map = CrossMap();
				break;

			case WUZHOU:
				map = WuZhouMap();
				break;

			case WUtoFU:
				map = WuToFuMap();
				break;

			case NANtoLIU:
				map = NanToLiuMap();
				break;

			case LIUZHOU:
				map = LiuZhouMap();
				break;

			case LIUtoWU:
				map = LiuToWuMap();
				break;

			default:
				break;
		}

		if( iOpenMusic)
		{
			mciSendString("stop BackMusic1", NULL, 0, NULL);
			mciSendString("stop BackMusic2", NULL, 0, NULL);
			mciSendString("play OpenDoor from 0", NULL, 0, NULL);
		}

		AlterScreen();	//ˢ��Ļ

		if(iOpenMusic)
			mciSendString("play BackMusic1 repeat", NULL, 0, NULL);
	}
}


//////////////////�ҵĵ�ͼ/////////////////
int HomeMap()
{
	IMAGE img,imgbkNum;

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/����.bmp");  //���ص�ͼ

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);	//���漴�������ǵ�ͼƬ

	// ʹ�� Windows GDI �����������
	TransparentBlt( dstDC, Owe.iX, Owe.iY, 30, 40, srcDC, 0, 0, 30, 40,  RGB(0,255,0));	//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();	// ʹ GDI ������Ч

	while(1)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire = getch();

		switch( Owe.iDire )
		{
			case UP:
				SetWorkingImage( &imgbkNum);	

				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					SetWorkingImage();	
					Owe.iY-=2;
					MoveImage( &imgbkNum);
				}

				else
				{
					SetWorkingImage();
					MoveImage(  &imgbkNum);
				}

				break;

			case DOWN:
				//�������ɫֵ
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if(getpixel( Owe.iX+15, Owe.iY+2+30) == lkclore)
					{
						Owe.iX=42;	//Ϊ������һ�ŵ�ͼʱ����ķ���������׼��
						Owe.iY=138;
						Owe.iNewDire=3;

						if(iOpenMusic)
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);

						//������һ�ŵ�ͼ
						return FUSUI;
					}

					Owe.iY+=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
				{
					Owe.iX-=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case RIGHT:
				if(getpixel( Owe.iX+2+24, Owe.iY+34)!= BanClore)
				{
					Owe.iX+=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return FUSUI;
}



//////////////�����ͼ////////////////
int FuSuiMap()
{
	IMAGE img,imgbkNum;
	COLORREF LNowClore,RNowClore;

	char cNum1[]="������n  �������ʣ��������ţ�n  ɽ���߶����ţ�ˮ��������塣�ֲ����ïʢ��·������ƽ̹��";
	char cNum2[]="����nһ������ս�ĵط�������n�������ﲻ�ǣ�����";
	char cNum3[]="�̵�n  ���Թ�����Ʒ������n  �Լ���Ϸ������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img,"ͼƬ/��ͼ/�����ͼ.bmp");  //���ص�ͼ,"""Bitmap",FUSUI

BEGIN:
	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));	
	FlushBatchDraw();

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		switch(Owe.iDire)
		{
			case UP:
				SetWorkingImage(&imgbkNum);
				LNowClore = getpixel(5, 30);
				RNowClore = getpixel(24, 30);
				if(LNowClore !=BanClore && RNowClore != BanClore)
				{
					if(LNowClore == HomeClore && RNowClore == HomeClore)	//�������
					{
						SetWorkingImage();
						Owe.iOldX = Owe.iX= 320;	//������������
						Owe.iOldY = Owe.iY= 435;
						Owe.iNewDire=2;
						//������һ�ŵ�ͼ						
						return HOME;
					}
					else if( LNowClore == ShopClore &&  RNowClore == ShopClore)	//�����̵�
					{
						SetWorkingImage();
						
						ShopMap();

						Owe.iX=485;
						Owe.iY=195;
						Owe.iNewDire=3;

						goto BEGIN;
					}
					else if( LNowClore == ClubClore &&  RNowClore == ClubClore)	//�������1
					{
						SetWorkingImage();
						Owe.iX=320;
						Owe.iY=435;
						Owe.iNewDire=2;

						ClubMap_1();

						Owe.iX=295;
						Owe.iY=300;
						Owe.iNewDire=3;
						goto BEGIN;
					}

					else if( LNowClore == RoadClore || RNowClore == RoadClore)	//����·��
					{
						SetWorkingImage();
						if(Owe.iX<300)
						{
							MoveImage( &imgbkNum);
							Road_1(cNum1);
						}
						else if(Owe.iX<450)
						{
							MoveImage( &imgbkNum);
							Road_1(cNum2);
						}
						else
						{
							MoveImage( &imgbkNum);
							Road_1(cNum3);
						}
					}

					else if( LNowClore == lkclore &&  LNowClore == lkclore)//�������������·��
					{
						SetWorkingImage();
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							continue;
						}
						Owe.iX=280;
						Owe.iY=440;
						Owe.iNewDire=2;
						//������һ�ŵ�ͼ
						return FUtoNAN;
					}
					else if( LNowClore != RoadClore)
					{
						SetWorkingImage();
						Owe.iY-=2;
						MoveImage( &imgbkNum);
					}
					else
					{
						SetWorkingImage();
						MoveImage( &imgbkNum);
					}
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
					Owe.iY+=2;

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
					Owe.iX-=2;

				MoveImage(&imgbkNum);

				break;

			case RIGHT:
				if( getpixel(Owe.iX+2+24,Owe.iY+34) == lkclore)
				{
					if( DetectionHP())
					{
						Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
						continue;
					}
					Owe.iX=15;
					Owe.iY=360;
					Owe.iNewDire=1;

					return CROSS_2;
				}
				else if( getpixel(Owe.iX+2+24,Owe.iY+34) != BanClore)
					Owe.iX+=2;

				MoveImage(&imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}

////////////////��⾫��HP/////////////////
int DetectionHP()
{
	int i;
	for(i=0;i<3;i++) 
		if(man.pet[i].iPH)
				break;

	if( i==3 )	//���о���HP��Ϊ0ʱ
		return TRUE;

	return FALSE;
}

///////���������ƶ�����Ŀ�ʼ����//////////
void SetOthrePeopleXY(int iX,int iY)
{
	int i;

	for(i=0;i<4;i++)
	{
		OthrePeople[i].iX=iX;	//��������
		OthrePeople[i].iY=iY;
	}

	OthrePeople[0].iX1=0;	//�ƶ�����
	OthrePeople[0].iY1=1;
	OthrePeople[1].iX1=1;
	OthrePeople[1].iY1=0;
	OthrePeople[2].iX1=-1;
	OthrePeople[2].iY1=0;
	OthrePeople[3].iX1=0;
	OthrePeople[3].iY1=-1;

	OthrePeople[0].iDire=DOWN;	//ͼƬ����
	OthrePeople[1].iDire=RIGHT;
	OthrePeople[2].iDire=LEFT;
	OthrePeople[3].iDire=UP;

	for(i = 0;i < 4;i++)	//���汻���ǵ�ͼƬ
		getimage( &OthrePeople[i].imgbkNum, OthrePeople[i].iX, OthrePeople[i].iY, 30, 40);
}
/////////////////�����˵��ƶ�//////////////
void OthrePeopleMove(IMAGE *img,int iX,int iY,int iFlag1)
{
	HDC dstDC;  //��ȡĿ�껷�����
	HDC srcDC;
	int i;
	static int iFlag=0;
	COLORREF LClore,RClore,UPClore,DownClore;
	static DWORD OldTime = GetTickCount();	//��ȡϵͳ����ʱ��

	BeginBatchDraw();

	putimage(iX,iY,img);

	SetWorkingImage(img);
	dstDC = GetImageHDC(img);

	for(i=0;i<4;i++)
		putimage( OthrePeople[i].iX, OthrePeople[i].iY, &OthrePeople[i].imgbkNum);


	if( GetTickCount() - OldTime > 60)
	{
		iFlag++;
		for(i = 0;i < 4;i++)
		{
			while(TRUE)
			{
				OthrePeople[i].iX += OthrePeople[i].iX1;
				OthrePeople[i].iY += OthrePeople[i].iY1;

				LClore = getpixel( OthrePeople[i].iX ,  OthrePeople[i].iY+38);	//��ȡ������������ɫֵ
				RClore = getpixel( OthrePeople[i].iX+25 , OthrePeople[i].iY+38);
				UPClore=getpixel(  OthrePeople[i].iX ,  OthrePeople[i].iY);
				DownClore=getpixel(OthrePeople[i].iX+25 , OthrePeople[i].iY);

				//�ж��Ƿ���ͨ�У�������ܣ��͸ı䷽��
				if( LClore!= BanClore &&  RClore != BanClore && UPClore!= BanClore &&
					DownClore!= BanClore && LClore !=lkclore && RClore!=lkclore )
					break;

				OthrePeople[i].iX -= OthrePeople[i].iX1;
				OthrePeople[i].iY -= OthrePeople[i].iY1;

				switch( rand()%4 ) //����ı䷽��
				{
					case 0:
						OthrePeople[i].iX1=0;
						OthrePeople[i].iY1=-2;
						OthrePeople[i].iDire=UP;
						break;

					case 1:
						OthrePeople[i].iX1=0;
						OthrePeople[i].iY1=2;
						OthrePeople[i].iDire=DOWN;
						break;

					case 2:
						OthrePeople[i].iX1=-2;
						OthrePeople[i].iY1=0;
						OthrePeople[i].iDire=LEFT;
						break;

					case 3:
						OthrePeople[i].iX1=2;
						OthrePeople[i].iY1=0;
						OthrePeople[i].iDire=RIGHT;
						break;
				}
			}

			getimage( &OthrePeople[i].imgbkNum, OthrePeople[i].iX, OthrePeople[i].iY, 30, 40); //���漴�������ǵ�ͼƬλ��
		}

		OldTime = GetTickCount();
	}


	for(i = 0;i < 4;i++)
	{
		if(iFlag>=3)	iFlag=0;

		switch(OthrePeople[i].iDire) //��ȡ��Ӧ�����ͼƬ
		{
			case UP:
				srcDC = GetImageHDC( &imgOtherPeople[i][2][iFlag]);
				break;

			case DOWN:
				srcDC = GetImageHDC( &imgOtherPeople[i][3][iFlag]);
				break;

			case LEFT:
				srcDC = GetImageHDC( &imgOtherPeople[i][0][iFlag]);
				break;

			case RIGHT:
				srcDC = GetImageHDC( &imgOtherPeople[i][1][iFlag]);
				break;

			default :
				break;
		}
		TransparentBlt(dstDC, OthrePeople[i].iX,OthrePeople[i].iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));
	}

	SetWorkingImage();
	dstDC = GetImageHDC();

	switch(Owe.iDire) //��ȡ��Ӧ�����ͼƬ
	{
		case UP:
			srcDC = GetImageHDC( &imgOwe[2][iFlag1]);
			break;

		case DOWN:
			srcDC = GetImageHDC( &imgOwe[3][iFlag1]);
			break;

		case LEFT:
			srcDC = GetImageHDC( &imgOwe[0][iFlag1]);
			break;

		case RIGHT:
			srcDC = GetImageHDC( &imgOwe[1][iFlag1]);
			break;

		default :
			srcDC = GetImageHDC( &imgOwe[3][iFlag1]);
			break;
	}

	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));

	FlushBatchDraw();
    EndBatchDraw();
}

//������������ƶ�����
void MoveImage(IMAGE *imgbkNum)
{
	static int iFlag=0;//������ﶯ��

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;

	if(iFlag>=3)	iFlag=0;

	switch(Owe.iDire) //��ȡ��Ӧ�����ͼƬ
	{
		case UP:
			srcDC = GetImageHDC( &imgOwe[2][iFlag++]);
			break;

		case DOWN:
			srcDC = GetImageHDC( &imgOwe[3][iFlag++]);
			break;

		case LEFT:
			srcDC = GetImageHDC( &imgOwe[0][iFlag++]);
			break;

		case RIGHT:
			srcDC = GetImageHDC( &imgOwe[1][iFlag++]);
			break;

		default :
			break;
	}
	
	BeginBatchDraw();
	putimage( Owe.iOldX, Owe.iOldY, imgbkNum);   //���ԭ�ȱ����ǵı���ͼƬ
	getimage( imgbkNum, Owe.iX, Owe.iY, 30, 40); //���漴�������ǵ�ͼƬλ��
	
	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч
    EndBatchDraw();

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	return;
}

////////////////�̵��ͼ////////////////
void ShopMap()
{
	IMAGE img,imgbkNum;
	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[2][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/�̵�.bmp");  //���ص�ͼ

	Owe.iX=110;//��������
	Owe.iY=430;
	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY; 

	if(iOpenMusic)
	{
		mciSendString("stop all", NULL, 0, NULL);
		mciSendString("play OpenDoor from 0", NULL, 0, NULL);
	}

	AlterScreen();

	if(iOpenMusic)
	{
		mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������
	}

BEGIN:
	putimage(0,0,&img);
	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч

	while(TRUE)   //�����ƶ�����
	{
		Sleep(1);

		Owe.iDire=getch();

		switch(Owe.iDire)
		{
			case UP:
				SetWorkingImage(&imgbkNum);
				if(getpixel(15, 30) == ComputerClore)	//�������
				{
					SetWorkingImage();
					PlayComputer();
					goto BEGIN;
				}
				else if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					SetWorkingImage();
					Owe.iY-=2;
					MoveImage( &imgbkNum);
				}
				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)//�˳��̵�
					{
						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						AlterScreen();

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL); //ѭ������	

						return ;
					}

					Owe.iY+=2;
					MoveImage(&imgbkNum);
				}

				else
					MoveImage(&imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
				{
					if(getpixel( Owe.iX-2+5, Owe.iY+34) == GouWuClore)	//���й���
					{
						MoveImage(&imgbkNum);
						Shopping();
					}

					else
					{
						Owe.iX-=2;
						MoveImage(&imgbkNum);
					}
				}

				else
					MoveImage(&imgbkNum);

				break;

			case RIGHT:
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
				{
					Owe.iX+=2;
					MoveImage(&imgbkNum);
				}

				else
					MoveImage(&imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return;
}

/////////////���й���˵�///////////////////////
void Shopping()
{
	char *str="����Ա:n  ����������Щʲô�������س���ѡ����n  �����Ҳ��㣬�ɵ��Ǳߵĵ�������������";
	char cNum[5];
	IMAGE img,imgRed;		//�˵�ͼƬ
	IMAGE img1[8];	//��һҳ��ƷͼƬ����ס�1����2�����˳���ͼ
	IMAGE img2[3];	//�ڶ�ҳ��ƷͼƬ

	IMAGE imgbkNum,imgbkNum1,imgbkNum2,imgbkNum3;	//���治ͬ����
	IMAGE imgPage1,imgPage2;	//�����һҳ�͵ڶ�ҳ�˵�
	IMAGE imgbk2;
	IMAGE imgbkMoney;
	IMAGE imgShop1,imgShop2,imgbkShop;

	int iKey;
	int iNum=0,iNum1=0;	//��Ǳ�ѡ����Ʒ
	int iExit=FALSE;	//�Ƿ��˳�
	int iPage=1;		//��ǵ�ǰҳ
	int iX=7,iY=63,iX2=7,iY2=63;	//��һ��ڶ�ҳ������
	int	iX1=14,iY1=264;				//��1����2�����˳���ͼ����
	int iShopping=FALSE;
	int i,j=0;

	HDC dstDC = GetImageHDC();			//��ȡĿ�껷�����
	HDC srcDC ;


	getimage(&imgbkNum1,0,0,195,307);	//����˵����ǲ���ͼƬ

	loadimage(&img,"ͼƬ/����/��Ʒ�˵�.bmp");

	loadimage(&imgRed,"ͼƬ/����/����˵���.bmp");	
	SetWorkingImage(&imgRed);
	for(i=0;i<8;i++)
		if(i<5)
			getimage(&img1[i],0,i*35,180,35);
		else
			getimage(&img2[j++],0,i*35,180,35);
	SetWorkingImage();

	loadimage(&img1[5],"ͼƬ/����/ѡ����1.bmp");
	loadimage(&img1[6],"ͼƬ/����/ѡ����2.bmp");
	loadimage(&img1[7],"ͼƬ/����/�˳���.bmp");
	loadimage(&imgPage2,"ͼƬ/����/�˵�2.bmp");
	loadimage(&imgShop1,"ͼƬ/����/����ɹ�.bmp");
	loadimage(&imgShop2,"ͼƬ/����/��Ҳ���.bmp");

	Road_2(str);

	putimage(0,0,&img);
	getimage(&imgbkMoney,0,0,195,55);
	
	getimage(&imgbkNum,iX,iY,180,36);

	srcDC = GetImageHDC(&img1[0]);
	TransparentBlt(dstDC, iX, iY, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 
	FlushBatchDraw();

	getimage(&imgbkNum2,iX1,iY1,25,25);

	sprintf(cNum,"%d",man.iMoney);
	outtextxy(100,20,cNum);
	srcDC = GetImageHDC(&img1[5]);
	TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();



	while(TRUE)	//������Ʒѡ��
	{
		DeviceKBBuf();

		iKey=getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		if(iExit)
		{
			while(iKey==UP||iKey==DOWN)
				iKey=getch();

			if(iKey==ENTER)
				break;
		}

		else if(iKey==ENTER)	//ȷ�Ϲ�����Ʒ
		{
			switch(iPage)
			{
				case 1:	//��һҳ��Ʒ
					switch(iNum)
					{
						case 0:
							if(man.iMoney>=10)
							{
								man.WuPin[0]++;
								man.iMoney-=10;
								iShopping=TRUE;
							}

							break;

						case 1:
							if(man.iMoney>=15)
							{
								man.WuPin[1]++; 
								man.iMoney-=15;
								iShopping=TRUE;
							}


							break;
						case 2:	
							if(man.iMoney>=20)
							{
								man.WuPin[2]++;	 
								man.iMoney-=20;
								iShopping=TRUE;
							}
							break;
						case 3:
							if(man.iMoney>=25)
							{
								man.WuPin[3]++; 
								man.iMoney-=25;
								iShopping=TRUE;
							}
						 	break;
						case 4:
							if(man.iMoney>=30)
							{
								man.WuPin[4]++; 
								man.iMoney-=30;
								iShopping=TRUE;
							}
						   break;
					}

					break;

				case 2:	//�ڶ�ҳ��Ʒ
					switch(iNum1)
					{
						case 0:
							if(man.iMoney>=35)
							{
								man.WuPin[5]++; 
								man.iMoney-=35;
								iShopping=TRUE;
							}
							 
							break;
						case 1:
							if(man.iMoney>=10)
							{
								man.WuPin[6]++; 
								man.iMoney-=10;
								iShopping=TRUE;
							}

							break;
						case 2:
							if(man.iMoney>=10)
							{
								man.WuPin[7]++; 
								man.iMoney-=10;
								iShopping=TRUE;
							}
							
							break;
					}

					break;

				default:
					break;
			}

			if(iShopping)
			{
				iShopping=FALSE;
				getimage(&imgbkShop,20,125,140,50);
				putimage(0,0,&imgbkMoney);
				sprintf(cNum,"%d",man.iMoney);
				outtextxy(100,20,cNum);
				srcDC = GetImageHDC(&imgShop1);
				TransparentBlt(dstDC, 20, 125, 140,50, srcDC, 0,0,140,50,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
				FlushBatchDraw();
				Sleep(500);
				putimage(20,125,&imgbkShop);
			}
			else
			{
				getimage(&imgbkShop,20,125,140,50);
				srcDC = GetImageHDC(&imgShop2);
				TransparentBlt(dstDC, 20, 125, 140,50, srcDC, 0,0,140,50,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
				FlushBatchDraw();
				Sleep(500);
				putimage(20,125,&imgbkShop);
			}
		}



		if(iPage==1)	//��Ʒ��һҳ
		{
			switch(iKey)
			{
				case UP:
					putimage(iX,iY,&imgbkNum);
					if(iY<=63)
						iY=207;
					else
						iY-=36;

					getimage(&imgbkNum,iX,iY,180,36);
					if(--iNum<0)
						iNum=4;

					srcDC = GetImageHDC(&img1[iNum]);
					TransparentBlt(dstDC, iX, iY, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
					FlushBatchDraw();// ʹ GDI ������Ч
					
					break;

				case DOWN:
					putimage(iX,iY,&imgbkNum);
					if(iY>=207)
						iY=63;
					else
						iY+=36;

					getimage(&imgbkNum,iX,iY,180,36);
					if(++iNum>4)
						iNum=0;

					srcDC = GetImageHDC(&img1[iNum]);
					TransparentBlt(dstDC, iX, iY, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
					FlushBatchDraw();// ʹ GDI ������Ч

					break;

				case LEFT:
					if(iX1==14)
					{
						putimage( iX, iY, &imgbkNum);
						putimage( iX1, iY1, &imgbkNum2);
						iX1=122;
						getimage(&imgbkNum3,iX1,iY1,46,23);	
						iExit=TRUE;

						srcDC = GetImageHDC(&img1[7]);
						TransparentBlt(dstDC, iX1, iY1, 46,23, srcDC, 0,0, 46,23,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 						FlushBatchDraw();
						FlushBatchDraw();
					}

					else if(iX1==122)
					{

						putimage( iX1, iY1,&imgbkNum3);
						iX1=47;
						getimage(&imgbkNum2,iX1,iY1,25,25);		
			
						iExit=FALSE;
						iPage=2;
						getimage(&imgPage1,7,63,180,182);
						putimage(7,63,&imgPage2);
						iKey=0;

						//�Եڶ�ҳ����ǰ����
						getimage(&imgbk2,iX2,iY2,180,36);
						srcDC = GetImageHDC(&img2[iNum1]);
						TransparentBlt(dstDC, iX2, iY2, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();// ʹ GDI ������Ч

						srcDC = GetImageHDC(&img1[6]);
						TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}
					
					break;

				case RIGHT:
					if(iX1==14)
					{
						putimage( iX1, iY1,&imgbkNum2);
						iX1=47;
						getimage(&imgbkNum2,iX1,iY1,25,25);	

						iExit=FALSE;
						iPage=2;
						iKey=0;

						getimage(&imgPage1,7,63,180,182);
						putimage(7,63,&imgPage2);
						getimage(&imgbk2,iX2,iY2,180,36);
						srcDC = GetImageHDC(&img2[iNum1]);
						TransparentBlt(dstDC, iX2, iY2, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();// ʹ GDI ������Ч

						srcDC = GetImageHDC(&img1[6]);
						TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}

					else
					{					
						putimage( iX1, iY1,&imgbkNum3);
						iX1=14;
						getimage(&imgbkNum2,iX1,iY1,25,25);	
						iExit=FALSE;

						srcDC = GetImageHDC(&img1[iNum]);//�Ե�һҳ
						TransparentBlt(dstDC, iX, iY, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();// ʹ GDI ������Ч

						srcDC = GetImageHDC(&img1[5]);
						TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}

					break;

				default:
					break;
			}
		}



		if(iPage==2)	//��Ʒ�ڶ�ҳ
		{

			switch(iKey)
			{
				case UP:
					putimage(iX2,iY2,&imgbk2);

					if(iY2<=63)
						iY2=134;
					else
						iY2-=36;

					getimage(&imgbk2,iX2,iY2,180,36);
					if(--iNum1<0)
						iNum1=2;

					srcDC = GetImageHDC(&img2[iNum1]);
					TransparentBlt(dstDC, iX2, iY2, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
					FlushBatchDraw();// ʹ GDI ������Ч
					
					break;

				case DOWN:
					putimage(iX2,iY2,&imgbk2);
					if(iY2>=134)
						iY2=63;
					else
						iY2+=36;

					getimage(&imgbk2,iX2,iY2,180,36);
					if(++iNum1>2)
						iNum1=0;

					srcDC = GetImageHDC(&img2[iNum1]);
					TransparentBlt(dstDC, iX2, iY2, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
					FlushBatchDraw();// ʹ GDI ������Ч

					break;

				case LEFT:
					if(iX1==47)
					{
					
						putimage( iX1, iY1,&imgbkNum2);
						iX1=14;
						getimage(&imgbkNum2,iX1,iY1,25,25);	

						iExit=FALSE;
						iPage=1;
						putimage(7,63,&imgPage1);
						iKey=0;

						//�Ե�һҳ����ǰ����
						srcDC = GetImageHDC(&img1[iNum]);
						TransparentBlt(dstDC, iX, iY, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();// ʹ GDI ������Ч

						srcDC = GetImageHDC(&img1[5]);
						TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}

					else
					{					
						putimage( iX1, iY1,&imgbkNum3);
						iX1=47;
						getimage(&imgbkNum2,iX1,iY1,25,25);	

						iExit=FALSE;

						srcDC = GetImageHDC(&img2[iNum1]);
						TransparentBlt(dstDC, iX2, iY2, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();// ʹ GDI ������Ч

						srcDC = GetImageHDC(&img1[6]);
						TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}
					break;

				case RIGHT:
					if(iX1==47)
					{
						putimage( iX2, iY2, &imgbk2);
						putimage( iX1, iY1,&imgbkNum2);
						iX1=122;
						getimage(&imgbkNum3,iX1,iY1,46,23);	
						iExit=TRUE;

						srcDC = GetImageHDC(&img1[7]);
						TransparentBlt(dstDC, iX1, iY1, 46,23, srcDC, 0,0, 46,23,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}

					else
					{					
						putimage( iX1, iY1,&imgbkNum3);
						iX1=14;
						getimage(&imgbkNum2,iX1,iY1,25,25);	

						iExit=FALSE;
						iPage=1;
						putimage(7,63,&imgPage1);
						iKey=0;

						//�Ե�һҳ����ǰ����
						srcDC = GetImageHDC(&img1[iNum]);
						TransparentBlt(dstDC, iX, iY, 180,35, srcDC, 0,0, 180,35,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();// ʹ GDI ������Ч

						srcDC = GetImageHDC(&img1[5]);
						TransparentBlt(dstDC, iX1, iY1, 25,25, srcDC, 0,0, 25,25,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
						FlushBatchDraw();
					}
				
					break;

				default:
					break;
			}
		}

	}

	putimage(0,0,&imgbkNum1);

	return;
}

/////////////////�������/////////////////
void PlayComputer()
{
	IMAGE imgbkNum,imgbkNum1;//������������һ���Ƶ�ͼƬ
	IMAGE imgbkPok,imgPoker,imgPokBK;	//�Ƶı������ơ����ƶ������ǵı���
	IMAGE imgTiShi[4][2],imgTS,imgbkTS;	//��ʾ
	IMAGE imgPok[13*4];			//52����
	IMAGE imgFinal[4],imgFina;
	IMAGE imgComptbk;

	float Score1,Score2;
	char  cNum[5];
	char  cWord[]="ʮ�����Ϸ����nÿһ��10��ң�Ӯ���10��ң������10��ң�n���5��δ�����20���";
	int   iPok1,iPok2;	//��¼��ҡ���������
	int	  iPokNum[10],iPokNum1=0,iPokNum2;	//��¼�Ѿ���ȡ����
	int   iFlag;	//���̵Ĳ���
	int   y;	//ѡ����
	int   iOpenPlay;


	loadimage(&imgbkNum,"ͼƬ/����/��/����.bmp");
	loadimage(&imgPoker,"ͼƬ/����/��/��.bmp");
	loadimage(&imgbkPok,"ͼƬ/����/��/�Ʊ�.bmp");
	loadimage(&imgTS,"ͼƬ/����/��/��ʾ.bmp");
	loadimage(&imgFina,"ͼƬ/����/��/��Ӯ.bmp");

	SetWorkingImage(&imgPoker);
	for(int i=0;i<13;i++)
		for(int j=0;j<4;j++)
			getimage(&imgPok[iPokNum1++],j*82,i*114,82,114);

	SetWorkingImage(&imgFina);
	for(i=0;i<4;i++)
		getimage(&imgFinal[i],0,i*40,115,40);

	SetWorkingImage(&imgTS);
	for(i=0;i<4;i++)
		for(int j=0;j<2;j++)
			getimage(&imgTiShi[i][j],j*82,i*24,82,24);
	SetWorkingImage();

	Road_1(cWord);

	if(iOpenMusic)
	{
		mciSendString("stop BackMusic2", NULL, 0, NULL);
		mciSendString("play PlayPok repeat", NULL, 0, NULL);
	}

	while(TRUE)
	{

BEGIN:
		Sleep(200);

		DeviceKBBuf();
		
		BeginBatchDraw();
		putimage(0,0,&imgbkNum);
		getimage(&imgbkTS,30,40,82,48);
		getimage(&imgbkNum1,30,40,160,360);

		sprintf(cNum,"%d",man.iMoney);
		outtextxy(510,35,cNum);

		putimage(30,40,&imgTiShi[0][1]);
		putimage(30,64,&imgTiShi[1][0]);

		FlushBatchDraw();
		EndBatchDraw();

		Score1=0.0,Score2=0.0;	//��Һ͵��Կ�ʼ����
		y=1;
		iOpenPlay=1;


		while(TRUE)	//�����Ƿ������Ϸ
		{
			iFlag=getch();

			if(iOpenMusic)
				mciSendString("play Key from 0", NULL, 0, NULL);

			switch(iFlag)
			{
				case UP:
					switch(y)
					{
						case 1://��ʾ��ӦͼƬ
							putimage(30,40,&imgTiShi[0][0]);
							putimage(30,64,&imgTiShi[1][1]);
							break;
						case 2:
							putimage(30,40,&imgTiShi[0][1]);
							putimage(30,64,&imgTiShi[1][0]);
							break;
					}

					if(y==1)	//������Ӧ�ж�
					{
						y=2;	iOpenPlay=0;	
					}
					else
					{
						y=1;	iOpenPlay=1;	
					}

					break;

				case DOWN:
					switch(y)
					{
						case 1:
							putimage(30,40,&imgTiShi[0][0]);
							putimage(30,64,&imgTiShi[1][1]);
							break;
						case 2:
							putimage(30,40,&imgTiShi[0][1]);
							putimage(30,64,&imgTiShi[1][0]);
							break;
					}

					if(y==1)
					{
						y=2;	iOpenPlay=0;	
					}
					else
					{
						y=1;	iOpenPlay=1;
					}

					break;

				default :
					break;
			}

			if(!iOpenPlay && (iFlag==ENTER))//����
			{
				if(iOpenMusic)
				{
					mciSendString("stop PlayPok", NULL, 0, NULL);
					mciSendString("play BackMusic2 repeat", NULL, 0, NULL);
				}

				return ;
			}

			else if(iOpenPlay && (iFlag==ENTER))//ȷ����Ϸ
			{

				if(man.iMoney<10)
				{
					putimage(255,288,&imgFinal[3]);
					Sleep(500);
					goto BEGIN;
				}

				putimage( 30, 40, &imgbkTS);
				break;
			}

		}
		
		//////��ʼ��Ϸ//////

		for(i=0;i<10;i++)	//���ԭ�����ݣ�Ϊ�µ�һ����׼��
			iPokNum[i]=-1;

		y=1;
		iPokNum1=0;//����

		iPokNum[iPokNum1]=GetPokNum(iPokNum);
		MovePok(508,150, &imgbkPok);
		putimage(508,150,&imgbkPok);		//��һ����
		MovePok(50,150, &imgbkPok);
		putimage(50,150,&imgPok[iPokNum[0]]);

		putimage(270,350,&imgTiShi[2][1]);	//��ʾ
		putimage(270,374,&imgTiShi[3][0]);

		while(TRUE)	//���ȡ��
		{
			DeviceKBBuf();

			iFlag=getch();

			if(iOpenMusic)
				mciSendString("play Key from 0", NULL, 0, NULL);

			if(iFlag == ENTER)
			{
				if(y==1 )
				{
					iPokNum[++iPokNum1] = GetPokNum(iPokNum);
					MovePok(50,150+iPokNum1*40, &imgbkPok);
					putimage( 50, 150+iPokNum1*40, &imgPok[iPokNum[iPokNum1]]);
				}
				else if(y==2)
					break;
			}

			Score1=0.0;
			if(iPokNum1>1)   //�������һ�����������Ƶĵ���
				for(i=1;i<=iPokNum1;i++)
				{
					if(iPokNum[i]>39)	//�ƴ���10��0.5��
						Score1+=0.5;
					else
						Score1+=iPokNum[i]/4+1;
				}

			if(Score1>=10.5)	//����һ�����������Ƶĵ���
			{					//����ʮ���֤������
				putimage(255,288,&imgFinal[1]);
				man.iMoney-=10;

				if(iOpenMusic)
				{
					mciSendString("stop PlayPok", NULL, 0, NULL);
					mciSendString("play Lose from 0", NULL, 0, NULL);
				}
				getch();

				if(iOpenMusic)
				{
					mciSendString("stop Lose",NULL,0,NULL);
					mciSendString("play PlayPok repeat", NULL, 0, NULL);
				}

				goto BEGIN;
			}

			if(iPokNum1 == 4)//�������ܳ������ţ������ͣ�
				break;


			switch(iFlag)
			{
				case UP:
					switch(y)
					{
						case 1://��ʾ��ӦͼƬ
							putimage(270,350,&imgTiShi[2][0]);
							putimage(270,374,&imgTiShi[3][1]);
							break;
						case 2:
							putimage(270,350,&imgTiShi[2][1]);
							putimage(270,374,&imgTiShi[3][0]);
							break;
					}
					if(y==1)//������Ӧ�ж�
						y=2;	
					else
						y=1;	
					break;

				case DOWN:
					switch(y)
					{
						case 1://��ʾ��ӦͼƬ
							putimage(270,350,&imgTiShi[2][0]);
							putimage(270,374,&imgTiShi[3][1]);
							break;
						case 2:
							putimage(270,350,&imgTiShi[2][1]);
							putimage(270,374,&imgTiShi[3][0]);
							break;
					}

					if(y==1)	//������Ӧ�ж�

						y=2;	
					else
						y=1;
					
					break;

				default :
					break;
			}
		 
		}

		putimage( 270, 350, &imgbkTS);

		//ͳ����ҵĵ���
		Score1=0;
		for(i=0;i<=iPokNum1;i++)
		{
			if(iPokNum[i]>39)	//�ƴ���10��0.5��
				Score1+=0.5;
			else
				Score1+=iPokNum[i]/4+1;
		}

		iPok1=iPokNum1+1;//�������

		//����ȡ��		
		iPokNum2 = iPokNum[++iPokNum1] = GetPokNum(iPokNum);

		if(iPokNum[iPokNum1]>39)
			Score2+=0.5;
		else
			Score2+=iPokNum[iPokNum1]/4+1;
		if(Score2<=8.0)
		{
			for(i=1;i<=4;i++)
			{
				iPokNum[++iPokNum1] = GetPokNum(iPokNum);
				MovePok(508, 150+i*40, &imgbkPok);
				putimage( 508, 150+i*40, &imgPok[iPokNum[iPokNum1]]);
				Sleep(1000);
				
				//ͳ�Ƶ��Եĵ���
				if(iPokNum[iPokNum1]>39)
					Score2+=0.5;
				else
					Score2+=iPokNum[iPokNum1]/4+1;

				if(Score2>=8.0)
					break;
			}
			getimage(&imgComptbk,508,190,82,270);
			putimage(508,150, &imgPok[iPokNum2]);
			putimage(508,190,&imgComptbk);
		}

		else
			putimage(508,150, &imgPok[iPokNum2]);

		iPok2=iPokNum1-iPok1+1;//��������

		if(((Score1<=10.5)&&(iPok1==5)) && ((Score2<=10.5)&&(iPok2==5)) )
		{
			putimage(255,288,&imgFinal[2]);//ƽ��
		}

		else if(((Score1<=10.5)&&(iPok1==5)) && ((Score2>10.5)||(iPok2!=5)))
		{
			if(iOpenMusic)
			{
				mciSendString("stop PlayPok", NULL, 0, NULL);
				mciSendString("play Win from 0", NULL, 0, NULL);
			}
			putimage(255,288,&imgFinal[0]);//Ӯ

			if(man.iMoney+20<32750)
				man.iMoney+=20;
		}
		else if(((Score2<=10.5)&&(iPok2==5)) && ((Score1>10.5)||(iPok1!=5)))
		{
			if(iOpenMusic)
			{
				mciSendString("stop PlayPok", NULL, 0, NULL);
				mciSendString("play Lose from 0", NULL, 0, NULL);
			}

			putimage(255,288,&imgFinal[1]);//��
			man.iMoney-=10;
		}
		else if((Score2 == Score1) && Score1<=10.5)
		{
			putimage(255,288,&imgFinal[2]);//ƽ��
		}
		else if(Score2>10.5 && Score1<=10.5)
		{
			if(iOpenMusic)
			{
				mciSendString("stop PlayPok", NULL, 0, NULL);
				mciSendString("play Win from 0", NULL, 0, NULL);
			}

			putimage(255,288,&imgFinal[0]);

			if(man.iMoney+10<32750)
				man.iMoney+=10;
		}
		else if(Score1>10.5 && Score2<=10.5)
		{
			if(iOpenMusic)
			{
				mciSendString("stop PlayPok", NULL, 0, NULL);
				mciSendString("play Lose from 0", NULL, 0, NULL);
			}

			putimage(255,288,&imgFinal[1]);
			man.iMoney-=10;
		}
		else if(Score2>10.5 && Score1>10.5)
		{
			putimage(255,288,&imgFinal[2]);
		}
		else if(Score2 < Score1)
		{
			if(iOpenMusic)
			{
				mciSendString("stop PlayPok", NULL, 0, NULL);
				mciSendString("play Win from 0", NULL, 0, NULL);
			}

			putimage(255,288,&imgFinal[0]);

			if(man.iMoney+10<32750)
				man.iMoney+=10;
		}
		else
		{
			if(iOpenMusic)
			{
				mciSendString("stop PlayPok", NULL, 0, NULL);
				mciSendString("play Lose from 0", NULL, 0, NULL);
			}

			putimage(255,288,&imgFinal[1]);
			man.iMoney-=10;
		}

		DeviceKBBuf();
		getch();

		if(iOpenMusic)
		{
			mciSendString("stop Lose",NULL,0,NULL);
			mciSendString("stop Win", NULL, 0, NULL);
			mciSendString("play PlayPok repeat", NULL, 0, NULL);
		}
	}


	return ;
}

//////////////ȡ��////////////////
int GetPokNum(int iPokNum[])
{
	int i,iNum=0,iFlag;

	do{		//��֤ÿһ���Ʋ�һ��--�ȷ�������ͬһ�ֳ�������÷��ʮ
		iNum=rand()%52;	

		iFlag=0;
		for(i=0;i<10;i++)
			if(iNum==iPokNum[i])
				iFlag=1;

	}while(iFlag);

	return iNum;
}

/////////////////�ƶ��˿�////////////////////
void MovePok(int iFinalX,int iFinalY,IMAGE *imgBKPok)
{
	int iX,iY=170;
	IMAGE imgBK;

	getimage(&imgBK,0,0,640,480);

	BeginBatchDraw();
	if(iFinalX<=270)
		for(int iX=270;iX>=50;iX-=2)
		{
			putimage(0,0,&imgBK);
			putimage(iX,iY,imgBKPok);
		    FlushBatchDraw();
			Sleep(10);
		}
	else 
		for(int iX=270;iX<=508;iX+=2)
		{
			putimage(0,0,&imgBK);
			putimage(iX,iY,imgBKPok);
		    FlushBatchDraw();
			Sleep(10);
		}

	iX=iFinalX;
	if(iFinalY<=170)
		for(int iY=170;iY>=iFinalY;iY-=2)
		{
			putimage(0,0,&imgBK);
			putimage(iX,iY,imgBKPok);
		    FlushBatchDraw();
			Sleep(10);
		}
	else
		for(int iY=170;iY<=iFinalY;iY+=2)
		{
			putimage(0,0,&imgBK);
			putimage(iX,iY,imgBKPok);
		    FlushBatchDraw();
			Sleep(10);
		}

	   EndBatchDraw();
}

///////////////�������-1��ͼ///////////////
void  ClubMap_1()
{
	IMAGE img,imgbkNum;
	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/��ʿ��.bmp");  //���ص�ͼ

	if(iOpenMusic)
	{
		mciSendString("stop all", NULL, 0, NULL);
		mciSendString("play OpenDoor from 0", NULL, 0, NULL);
	}

	AlterScreen();

	if(iOpenMusic)
	{
		mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������
	}

	putimage(0,0,&img);

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч

	while(1)   //�����ƶ�����
	{
		Sleep(1);

		Owe.iDire=getch();

		switch(Owe.iDire)
		{
			case UP:
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					SetWorkingImage();
					Owe.iY-=2;
					MoveImage(&imgbkNum);
				}
				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)
					{
						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						AlterScreen();

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL); //ѭ������	

						return ;
					}

					Owe.iY+=2;
					MoveImage(&imgbkNum);
				}

				else
					MoveImage(&imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
				{
					Owe.iX-=2;
					MoveImage(&imgbkNum);
				}

				else
					MoveImage(&imgbkNum);

				break;

			case RIGHT:
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
				{
					Owe.iX+=2;
					MoveImage(&imgbkNum);
				}

				else
					MoveImage(&imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return ;
}

///////////////���ݵ�ͼ2///////////////
void  ClubMap_2()
{
	IMAGE img,img2,imgbkNum;
	int iY=-320;
	int iFlag=0;
	int iKO[5]={0};     //����Ƿ���ս�ɹ�
	int i;

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC ;
	
	loadimage(&img, "ͼƬ/��ͼ/����.bmp");  //���ص�ͼ480*800
	Owe.iX=317;
	Owe.iY=435;
	Owe.iNewDire=2;

	if(iOpenMusic)
	{
		mciSendString("stop all", NULL, 0, NULL);
		mciSendString("play OpenDoor from 0", NULL, 0, NULL);
	}

	AlterScreen();

	if(iOpenMusic)
	{
		mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������
	}


BEGIN:
	BeginBatchDraw();
	setbkcolor(BLACK);
	cleardevice();
	putimage(80,iY,&img);

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		switch(Owe.iDire)
		{
			case UP:
				SetWorkingImage( &imgbkNum);
				if( getpixel(15, 30) == GouWuClore )
				{
					SetWorkingImage();

			    	MoveImage(&imgbkNum);
					if(Owe.iY>=190)//��һ��ѵ����
					{
						Owe.iNewDire=2;
						if( iKO[0])
						{
							Road_2("ѵ���ң�n  �벻���㾹Ȼ��ô����������n  �������ս����ѵ�����ˣ�����");

							goto BEGIN;
						}

						Road_2("ѵ���ң�n  С�ܵܣ���ȷ��Ҫ������ս��n  �Ǿ����ɣ�����");

						if( !iKO[0] && ClubZhanChang_1( rand()%2+1 ) )
						{
							iKO[0]=1; //��ս�ɹ�

							goto BEGIN;
						}

						else
						{
							Road_2("ѵ���ң�n  С�ܵܣ���̫���ˣ��������ҵĶ���n  ��ȥ�ú������ɣ�����");
							setbkcolor(WHITE);

							if(iOpenMusic)
							{
								mciSendString("stop BackMusic2", NULL, 0, NULL);
								mciSendString("play OpenDoor from 0", NULL, 0, NULL);
							}

							if(iOpenMusic)
								mciSendString("play BackMusic1 repeat", NULL, 0, NULL);

							return ;
						}
					}

					else if(Owe.iY>=130)//�ڶ���ѵ����
					{
						Owe.iNewDire=2;
						if( iKO[1])
						{
							Road_2("ѵ���ң�n  �Ҿ�Ȼ���ˣ�ǧ��ҪС�����ӣ�����n  �������ս����ѵ�����ˣ�����");
							goto BEGIN;
						}
						
						Road_2("ѵ���ң�n  ���ӣ���ȷ��Ҫ������ս��n  ׼�����˾����ɣ�����");

						if( !iKO[1] && ClubZhanChang_1( rand()%2+1 ) )
						{
							iKO[1]=1;

							goto BEGIN;
						}

						else
						{
							Road_2("ѵ���ң�n  ���ӣ��㻹С���������ҵĶ���n  ��ȥ�ú�������ɣ�����");
							setbkcolor(WHITE);

							if(iOpenMusic)
							{
								mciSendString("stop BackMusic2", NULL, 0, NULL);
								mciSendString("play OpenDoor from 0", NULL, 0, NULL);
							}

							if(iOpenMusic)
								mciSendString("play BackMusic1 repeat", NULL, 0, NULL);

							return ;
						}
					}

					else//������ѵ����
					{
						Owe.iNewDire=2;
						for(i=0;i<4;i++)
							if( !iKO[i])
							{
								Road_2("ѵ�����죺n  ����ȥ��ս�ҵ����ж��ѣ�����n  Ȼ������������ս������");
								goto BEGIN;
							}

						if( iKO[4])
						{
							Road_2("ѵ�����죺n  �濴�����������Ȼ������������n  ȥ�������ð�հɣ�����");
							goto BEGIN;
						}

						Road_2("ѵ�����죺n  ����������Ҫ������ս��n  �һ�������ú��ѿ��ģ�����");

						if( ClubZhanChang_1( 3 ) )
						{
							iKO[4]=1;
							
							goto BEGIN;
						
						}
						else
						{
							Road_2("ѵ���ң�n  ���ӣ���Ҫ���ģ���ȥ�ú������꣡����n  ϣ���´μ�����ʱ������ø�����������");
							setbkcolor(WHITE);

							if( iOpenMusic)
							{
								mciSendString("stop BackMusic2", NULL, 0, NULL);
								mciSendString("play OpenDoor from 0", NULL, 0, NULL);
							}

							if( iOpenMusic)
								mciSendString("play BackMusic1 repeat", NULL, 0, NULL);

							return ;
						}	
					}
				}

				else if((getpixel(5, 30) != BanClore) && (getpixel(24, 30) != BanClore))
				{
					SetWorkingImage();

					if(Owe.iY<=240 && iY<0)//����ͼ�ƶ�
					{
						for(int i=1;i<=2;i++)
						{
							iY+=1;

							BeginBatchDraw();

							putimage(80,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[2][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;	    
						}
					}

					else
					{
						Owe.iY-=2;
						MoveImage( &imgbkNum);
					}
				}


				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				if( (getpixel( Owe.iX+5, Owe.iY+ 2+ 34) != BanClore) && (getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore))
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)
					{
						setbkcolor(WHITE);

						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						AlterScreen();

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL);	
						
						return ;
					}

					else if(Owe.iY>=240 && iY>-320)
					{
						for(int i=1;i<=2;i++)
						{
							iY-=1;
							BeginBatchDraw();

							putimage(80,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[3][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
							
						}
					}

					else
						Owe.iY+=2;

				}

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34) == GouWuClore)
				{
					MoveImage(&imgbkNum);

					Owe.iNewDire=0;
					if(iKO[2])
					{
						Road_2("ѵ���ң�n  ��������������n  �������ս����ѵ�����ˣ�����");
						goto BEGIN;
					}

					Road_2("ѵ���ң�n  ���ѣ��㿴��������СŶ��n  ���Ҳ�����������ģ�����");

					if( ClubZhanChang_1( rand()%2+1 ) )
					{
						iKO[2]=1;
						goto BEGIN;
					}
					else
					{
						Road_2("ѵ���ң�n  ��˵�����С�������ҵĶ���n  ��ȥ�ú�������ɣ�����");
						setbkcolor(WHITE);

						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL);

						return ;
					}
				}
				else if(getpixel( Owe.iX-2+5, Owe.iY+34) != BanClore)
					Owe.iX-=2;

				MoveImage(&imgbkNum);

				break;

			case RIGHT:
				if( getpixel(Owe.iX+2+24,Owe.iY+34) == GouWuClore)
				{
					MoveImage(&imgbkNum);
					Owe.iNewDire=1;
					if(iKO[3])
					{
						Road_2("ѵ���ң�n  ��������������n  �������ս����ѵ�����ˣ�����");
						goto BEGIN;
					}

					Road_2("ѵ���ң�n  Ŷ��������������ս����n  �Ҳ�����������ģ�����");

					if( ClubZhanChang_1( rand()%2+1 ) )
					{
						iKO[3]=1;
						goto BEGIN;
					}
					else
					{
						Road_2("ѵ���ң�n  ������n  ��Ӯ�ˣ�����");
						setbkcolor(WHITE);
						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL);

						return ;
					}
				}
				else if( getpixel(Owe.iX+2+24,Owe.iY+34) != BanClore)
					Owe.iX+=2;

				MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}

	return ;
}


////////////��ʾ��ʾ����////////////
void Road_1(char *str)
{
	IMAGE img,imgbkNum;
	loadimage(&img,"ͼƬ/�Ի���.bmp");
	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&img);

	getimage( &imgbkNum,0, 350, 640, 120);

	char cNum[60]="";
	int iFlag=1,iSize;

	TransparentBlt(dstDC,0, 350,  640, 120, srcDC, 0,0,  640, 120,  RGB(0,255,0));		
	FlushBatchDraw();

	iSize=strlen(str);

	for(int i=0;i<iSize;i++)
		if(str[i]=='n')		//���в���
		{
			switch(iFlag)
			{
				case 1:	//��һ��
					strncpy(cNum,str,i);
					outtextxy(30,365,cNum);	
					str=str+i+1;
					iSize=strlen(str);
					i=0;
					break;

				case 2:		//�ڶ���
					strncpy(cNum,str,i);	
					cNum[i]='\0';
					outtextxy(30,389,cNum); 
					str=str+i+1;
					iSize=strlen(str);
					i=0;

					break;
			}
			iFlag++;
		}

	outtextxy(30,413,str); //������
	EndBatchDraw();

	while(getch()==UP);

	putimage(0,350,&imgbkNum);

	return;
}

///////////////////�Ի���ʾ////////////////
void Road_2(char *str)
{
	IMAGE img,imgbkNum;
	loadimage(&img,"ͼƬ/�Ի���.bmp");
	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&img);

	getimage( &imgbkNum,0, 350, 640, 120);

	char cNum[60],*pStr,cNum1[3];
	int  iSize,iFlag=1;
	pStr=cNum;

	TransparentBlt(dstDC,0, 350,  640, 120, srcDC, 0,0,  640, 120,  RGB(0,255,0));		
	FlushBatchDraw();

	iSize=strlen(str);

	for(int i=0;i<iSize;i++)
		if(str[i]=='n')
		{
			switch(iFlag)
			{
				case 1:	//��һ��
					strncpy(pStr,str,i);
					pStr[i]='\0';
					outtextxy(30,365,pStr);	
					str=str+i+1;
					iSize=strlen(str);
					i=0;
					break;

				case 2:		//�ڶ���
					strncpy(pStr,str,i);	
					pStr[i]='\0'; 
					str=str+i+1;

					for( i=0; strlen(pStr); i++)	//һ��һ���ֵ����
					{			
						strncpy(cNum1,pStr,2);
						cNum1[2]='\0';
						pStr=pStr+2;
						outtextxy(30+i*24,389,cNum1); 
						Sleep(150);
					}

					break;
			}
			iFlag++;
		}

	for( i=0; strlen(str); i++)	//һ��һ���ֵ����
	{			
		strncpy(cNum,str,2);
		cNum[2]='\0';
		str=str+2;
		outtextxy(30+i*24,413,cNum); 
		Sleep(150);
	}

	Sleep(1000);

	putimage(0,350,&imgbkNum);
	DeviceKBBuf();

	EndBatchDraw();
	return;
}

///////////////����������·;��ͼ////////////
int  FuToNanMap()
{
	IMAGE img,imgbkNum;
	COLORREF NowClore;
	int iY;
	int i,iFlag=0;
	int iStep,iStepNum=0;	//��ǲ�����

	char cNum1[]="���硪������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/�����ϵ�ͼ.bmp");  //���ص�ͼ640*800

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	if(	Owe.iOldY>240)
	{
		putimage(0,-320,&img);
		iY=-320;
	}
	else
	{
		putimage(0,0,&img);
		iY=0;
	}


	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);


	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();
	iStep=rand()%100+100;

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if( DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=325;
				Owe.iY=5;
				Owe.iNewDire=3;
				return FUSUI;
			}

			putimage(0,iY,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					NowClore = getpixel(15,30);

					if( NowClore == RoadClore)	//����·��
					{
						SetWorkingImage();
						MoveImage( &imgbkNum);
						Road_1(cNum1);
					}

					else if( NowClore == lkclore)//����·��
					{
						SetWorkingImage();
						Owe.iX=96;
						Owe.iY=430;
						Owe.iNewDire=2;

						return NANNING;
					}
					else if( NowClore != RoadClore)
					{
						SetWorkingImage();

						if(Owe.iY<=240 && iY<0)//����ͼ�ƶ�
						{
							for(i=1;i<=2;i++)
							{
								iY+=1;

								BeginBatchDraw();

								putimage(0,iY,&img);
								getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
								srcDC = GetImageHDC( &imgOwe[2][iFlag++]);
								TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

								FlushBatchDraw();
								EndBatchDraw();

								if(iFlag>=3) iFlag=0;
						    
							}

						}

						else
						{
							Owe.iY-=2;
							MoveImage( &imgbkNum);
						}
					}

					else
						SetWorkingImage();
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)
					{
						Owe.iX=325;
						Owe.iY=5;
						Owe.iNewDire=3;
						//������һ�ŵ�ͼ
						return FUSUI;
					}

					else if(Owe.iY>=240 && iY>-320)
					{
						for(i=1;i<=2;i++)
						{
							iY-=1;
							BeginBatchDraw();

							putimage(0,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[3][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
							
						}
					}

					else
					{
						Owe.iY+=2;
						MoveImage( &imgbkNum);
					}

				}

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
					Owe.iX-=2;

				MoveImage(&imgbkNum);

				break;

			case RIGHT:
				iStepNum++;
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
					Owe.iX+=2;

				MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}

/////////////////////////������ͼ////////////////////
int NanNingMap()
{
	IMAGE img,imgbkNum;
	COLORREF LNowClore,RNowClore;
	int i,iX,iFlag=0,iFlag1=0;

	char cNum1[]="������n  ����׳���������׸���������һ����С�n  ��ס��׳��������36���������壬ӵ�����ٶ����˿ڡ�";
	char cNum2[]="�����е���n  ��ս��һ�����о���HPֵ��Ϊ�㽫������ս������n  ��ʾ��ս������׼��������";
	char cNum3[]="����ʾn  һ��һ��������  �۸���򣡣���n  ��ϵ�绰��110 ";
	char cNum4[]="�̵�n  ���Թ�����Ʒ������n  �Լ���Ϸ������";
	char cNum5[]="������ʾn  һ��һ��������  ÿ����ǧ������n  ��ϵ�绰��119 ";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;
	
	loadimage(&img, "ͼƬ/��ͼ/������ͼ.bmp");  //���ص�ͼ1000*480

	if(Owe.iX<100)
	{
		iX=0;
	}
	else
	{
		iX=-360;
	}
	putimage(iX,0,&img);
	SetOthrePeopleXY(320,80);



BEGIN:
	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	putimage(iX,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч


	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		while(kbhit())
		{
			Owe.iDire=getch();

    		switch(Owe.iDire)
			{
				case UP:
					LNowClore=getpixel( Owe.iX+5, Owe.iY-2+ 35);
					RNowClore=getpixel( Owe.iX+22, Owe.iY-2+ 35);				
					if(LNowClore == HomeClore && RNowClore == HomeClore )	//�������
					{					
						//��ͼ��ͬ����ʱ���겻ͬ
						if(Owe.iY>240)
						{					
							OtherHomeMap_1();

							Owe.iX= 320;
							Owe.iY= 363;
							Owe.iNewDire=3;	
						}

						else
						{				
							OtherHomeMap_2();

							Owe.iX= 320;
							Owe.iY= 73;
							Owe.iNewDire=3;	
						}

		
						goto BEGIN;
					}

					else if( LNowClore == ShopClore &&  RNowClore == ShopClore)	//�����̵�
					{
						ShopMap();

						Owe.iX=320;
						Owe.iY=110;
						Owe.iNewDire=3;

						goto BEGIN;
					}
					else if( LNowClore == ClubClore &&  RNowClore == ClubClore)	//�������1
					{
						for(i=0;i<3;i++) 
							if(man.pet[i].iPH)
								break;
						if(i==3)
						{
							Road_2("��ʾ��n  û�п���ս���ľ��飡����n  ��Ϊ����伢�ɣ�����");
							goto BEGIN;
						}

						ClubMap_2();

						Owe.iX=355;
						Owe.iY=310;
						Owe.iNewDire=3;
						goto BEGIN;
					}

					else if( LNowClore == RoadClore || LNowClore == RoadClore)	//·��
					{
						if(Owe.iX<160)
							Road_1(cNum1);
						else if(Owe.iX>330)
							Road_1(cNum2);
						else if(Owe.iY>340)
							Road_1(cNum3);
						else if(Owe.iY>90)
							Road_1(cNum4);
						else 
							Road_1(cNum5);
					}

					else if( LNowClore !=BanClore &&  RNowClore !=BanClore &&  LNowClore != RoadClore)
						Owe.iY-=2;

					iFlag1++;

					break;

				case DOWN:
					if(getpixel( Owe.iX+5, Owe.iY+ 2+ 35) != BanClore && getpixel( Owe.iX+22, Owe.iY+2+35)!= BanClore)
					{
						Owe.iY+=2;
						if( getpixel( Owe.iX+5, Owe.iY+ 2+ 35) == lkclore)
						{
							if(Owe.iX<200)
							{
								if(DetectionHP())
								{
									Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
									goto BEGIN;
								}

								Owe.iX=90;
								Owe.iY=5;
								Owe.iNewDire=3;
								
								return FUtoNAN;
							}
							else
							{
								if(DetectionHP())
								{
									Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
									goto BEGIN;
								}

								Owe.iX=70;
								Owe.iY=5;
								Owe.iNewDire=3;
								
								return NANtoBEI;
							}
						}
					}
					iFlag1++;

					break;

				case LEFT:
					if(getpixel( Owe.iX-2+5, Owe.iY+35)!= BanClore)
					{
						if( Owe.iX<=320 && iX<0)
							iX+=2;
						else 
							Owe.iX-=2;
					}
					iFlag1++;

					break;

				case RIGHT:
					if( getpixel(Owe.iX+2+22,Owe.iY+35) == lkclore)
					{			
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							goto BEGIN;
						}
						Owe.iX=15;
						Owe.iY=210;
						Owe.iNewDire=1;
								
						return NANtoLIU;
					}
					else if( getpixel(Owe.iX+2+22,Owe.iY+34)!= BanClore)
					{
						if( Owe.iX>=320 && iX>-360)
							iX-=2;
						else
							Owe.iX+=2;
					}
					iFlag1++;

					break;

				case SPACE:
					Menu2();
					break;

				default :
					break;
			}
		}
		if(iFlag1>=3)	iFlag1=0;

		OthrePeopleMove(&img,iX,0,iFlag1);
	}

	return HOME;
}

/////////////////////���������ݵ�ͼ/////////////////
int NanToLiuMap()
{
	IMAGE img,imgbkNum;
	int iX;
	int i,iFlag=0;
	int iStep,iStepNum=0;	//��ǲ�����

	char cNum1[]="������������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/��������ͼ.bmp");  //���ص�ͼ1000*480

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	if(	Owe.iOldX>240)
		iX=-360;
	else
		iX=0;

	putimage(iX,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);


	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();
	iStep=rand()%100+100;

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if(DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=605;
				Owe.iY=153;
				Owe.iNewDire=0;

				return NANNING;
			}

			putimage(iX,0,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30) == RoadClore && getpixel(24, 30) == RoadClore)
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
					Road_1(cNum1);
				}
				else if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					SetWorkingImage();
					Owe.iY-=2;
					MoveImage( &imgbkNum);		
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
					Owe.iY+=2;

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34) == lkclore)
				{
					Owe.iX=605;
					Owe.iY=153;
					Owe.iNewDire=0;

					return NANNING;
				}

				else if(getpixel( Owe.iX-2+5, Owe.iY+34) != BanClore)
				{
					if(iX<0 && Owe.iX<=240)//����ͼ�ƶ�
					{
						for(i=1;i<=2;i++)
						{
							iX+=1;

							BeginBatchDraw();

							putimage(iX,0,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[0][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						
						}
					}

					else
					{
						Owe.iX-=2;
						MoveImage(&imgbkNum);
					}
				}

				else
					MoveImage(&imgbkNum);

				break;

			case RIGHT:
				iStepNum++;
				if(getpixel(Owe.iX+2+24,Owe.iY+34) == lkclore)
				{
					Owe.iX=15;
					Owe.iY=328;
					Owe.iNewDire=1;

					return LIUZHOU;
				}
				else if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
				{
					if(iX>-360 && Owe.iX>=240)//����ͼ�ƶ�
					{
						for(i=1;i<=2;i++)
						{
							iX-=1;

							BeginBatchDraw();

							putimage(iX,0,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[1][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						}
					}

					else
					{
						Owe.iX+=2;
						MoveImage(&imgbkNum);
					}
				}
				else
					MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}
	return HOME;
}

///////////////////////���ݵ�ͼ/////////////////////
int LiuZhouMap()
{
	IMAGE img,imgbkNum;
	COLORREF LNowClore,RNowClore;
	int i,iX,iY,iFlag=0,iFlag1=0;

	char cNum1[]="������n  �ֳ����ǣ�������Ҫ���������ĳ��У�����n  ������ҵ���ǣ���ʷ���ǣ��Ļ����ǣ��������ǡ�";
	char cNum2[]="�����е���n  ��ս��һ�����о���HPֵ��Ϊ�㽫������ս������n  ��ʾ��ս������׼��������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;
	
	loadimage(&img, "ͼƬ/��ͼ/���ݵ�ͼ.bmp");  //���ص�ͼ1000*480

	if(Owe.iY<400)
	{
		iX=0,iY=0;
	}
	else
	{
		iX=-360,iY=-520;
	}

BEGIN:
	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	putimage(iX,iY,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire = getch();

    	switch( Owe.iDire)
		{
			case UP:
				SetWorkingImage(&imgbkNum);
				LNowClore = getpixel(5, 30);
				RNowClore = getpixel(24, 30);
				if(LNowClore !=BanClore && RNowClore != BanClore)
				{
					SetWorkingImage();

					if( LNowClore == ShopClore &&  RNowClore == ShopClore)	//�����̵�
					{
						MoveImage(&imgbkNum);

						ShopMap();

						Owe.iX=370;
						Owe.iY=110;
						Owe.iNewDire=3;

						goto BEGIN;
					}
					else if( LNowClore == ClubClore &&  RNowClore == ClubClore)	//�������1
					{
						MoveImage(&imgbkNum);
						for(i=0;i<3;i++) 
							if(man.pet[i].iPH)
								break;

						if(i==3)
						{
							Road_2("��ʾ��n  û�п���ս���ľ��飡����n  ��Ϊ����伢�ɣ�����");
							continue;
						}

						ClubMap_2();

						Owe.iX=472;
						Owe.iY=45;
						Owe.iNewDire=3;
						goto BEGIN;
					}

					else if( LNowClore == RoadClore ||  RNowClore == RoadClore)	//����·��
					{
						MoveImage(&imgbkNum);
						if(Owe.iX<300)
							Road_1(cNum1);
						else
							Road_1(cNum2);
					}

					else
					{
						if( Owe.iY<=240 && iY<0)
						{
							for(int i=1;i<=2;i++)
							{
								iY+=1;

								BeginBatchDraw();

								putimage(iX,iY,&img);
								getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
								srcDC = GetImageHDC( &imgOwe[2][iFlag++]);
								TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

								FlushBatchDraw();
								EndBatchDraw();

								if(iFlag>=3) iFlag=0;
								
							}
						}

						else
						{
							Owe.iY-=2;
							MoveImage(&imgbkNum);
						}
					}
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}
				
				break;

			case DOWN:
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							continue;
						}

						Owe.iX=430;
						Owe.iY=5;
						Owe.iNewDire=3;
						
						return LIUtoWU;
					}

					else if( iY>-520 && Owe.iY>=240 )
					{
						for(int i=1;i<=2;i++)
						{
							iY-=1;

							BeginBatchDraw();

							putimage(iX,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[3][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						}
					}

					else
					{
						Owe.iY+=2;	
					    MoveImage(&imgbkNum);
					}
				}
				MoveImage(&imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
				{
					if(getpixel( Owe.iX-2+5, Owe.iY+34) == lkclore)
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							continue;
						}

						Owe.iX=600;
						Owe.iY=430;
						Owe.iNewDire=0;
						
						return NANtoLIU;
					}
					else if( Owe.iX<320 && iX<0)
					{
						for(int i=1;i<=2;i++)
						{
							iX+=1;

							BeginBatchDraw();

							putimage(iX,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[0][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						}
					}
					else 
					{
						Owe.iX-=2;
						MoveImage(&imgbkNum);
					}

				}
				MoveImage(&imgbkNum);

				break;

			case RIGHT:
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
				{
					if( Owe.iX>320 && iX>-360)
					{
						for(int i=1;i<=2;i++)
						{
							iX-=1;

							BeginBatchDraw();

							putimage(iX,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[1][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						}
					}
					else
					{
						Owe.iX+=2;	
						MoveImage(&imgbkNum);
					}
				}
				MoveImage(&imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
			}

		}

	return HOME;
}

////////////////////////����������//////////////////
int LiuToWuMap()
{
	IMAGE img,imgbkNum;
	COLORREF NowClore;
	int iY;
	int i,iFlag=0;
	int iStep,iStepNum=0;	//��ǲ�����

	char cNum1[]="���ݡ�������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/�������ͼ.bmp");  //���ص�ͼ640*1000

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	if(	Owe.iOldY>240)
		iY=-520;

	else
		iY=0;

	putimage(0,iY,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);


	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();
	iStep=rand()%100+100;

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if(DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=205;
				Owe.iY=430;
				Owe.iNewDire=2;

				return LIUZHOU;
			}

			putimage(0,iY,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					NowClore = getpixel(15,30);

					if( NowClore == RoadClore)	//����·��
					{
						SetWorkingImage();
						MoveImage( &imgbkNum);
						Road_1(cNum1);
					}

					else if( NowClore == lkclore)//����·��
					{
						SetWorkingImage();
						Owe.iX=205;
						Owe.iY=430;
						Owe.iNewDire=2;

						return LIUZHOU;
					}
					else if( NowClore != RoadClore)
					{
						SetWorkingImage();

						if(Owe.iY<=240 && iY<0)//����ͼ�ƶ�
						{
							for(i=1;i<=2;i++)
							{
								iY+=1;

								BeginBatchDraw();

								putimage(0,iY,&img);
								getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
								srcDC = GetImageHDC( &imgOwe[2][iFlag++]);
								TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

								FlushBatchDraw();
								EndBatchDraw();

								if(iFlag>=3) iFlag=0;
						    
							}

						}

						else
						{
							Owe.iY-=2;
							MoveImage( &imgbkNum);
						}
					}

					else
						SetWorkingImage();
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)
					{
						Owe.iX=510;
						Owe.iY=5;
						Owe.iNewDire=3;
						return WUZHOU;
					}

					else if(Owe.iY>=240 && iY>-520)
					{
						for(i=1;i<=2;i++)
						{
							iY-=1;
							BeginBatchDraw();

							putimage(0,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[3][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
							
						}
					}

					else
					{
						Owe.iY+=2;
						MoveImage( &imgbkNum);
					}

				}

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
					Owe.iX-=2;

				MoveImage(&imgbkNum);

				break;

			case RIGHT:
				iStepNum++;
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
					Owe.iX+=2;

				MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}
////////////////////////���˼���1///////////////////
void OtherHomeMap_1()
{
	IMAGE img,imgbkNum;

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC ;

	loadimage(&img, "ͼƬ/��ͼ/���˼�.bmp");  //���ص�ͼ640*480

	Owe.iOldX= Owe.iX= 310;	//������������
	Owe.iOldY= Owe.iY= 435;
	Owe.iNewDire=2;	

	if(iOpenMusic)
	{
		mciSendString("stop all", NULL, 0, NULL);
		mciSendString("play OpenDoor from 0", NULL, 0, NULL);
	}

	AlterScreen();

	if(iOpenMusic)
	{
		mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������
	}

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);	//���漴�������ǵ�ͼƬ

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	// ʹ�� Windows GDI �����������
	TransparentBlt( dstDC, Owe.iX, Owe.iY, 30, 40, srcDC, 0, 0, 30, 40,  RGB(0,255,0));	//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();	// ʹ GDI ������Ч

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire = getch();

		switch( Owe.iDire )
		{
			case UP:
				SetWorkingImage( &imgbkNum);	

				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					SetWorkingImage();	
					Owe.iY-=2;
					MoveImage( &imgbkNum);
				}

				else
				{
					SetWorkingImage();
					MoveImage( &imgbkNum);
				}

				break;

			case DOWN:
				//�������ɫֵ
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if(getpixel( Owe.iX+15, Owe.iY+2+30) == lkclore)
					{
						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						AlterScreen();

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL); 

						return ;
					}

					Owe.iY+=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
				{
					Owe.iX-=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case RIGHT:
				if(getpixel( Owe.iX+2+24, Owe.iY+34)!= BanClore)
				{
					Owe.iX+=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return;
}

/////////////////////////���˼���2//////////////////
void OtherHomeMap_2()
{
	IMAGE img,imgbkNum;

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC ;

	loadimage(&img, "ͼƬ/��ͼ/���˼�1.bmp");  //���ص�ͼ640*480

	Owe.iOldX= Owe.iX= 300;	//������������
	Owe.iOldY= Owe.iY= 435;
	Owe.iNewDire=2;	

	if(iOpenMusic)
	{
		mciSendString("stop all", NULL, 0, NULL);
		mciSendString("play OpenDoor from 0", NULL, 0, NULL);
	}

	AlterScreen();

	if(iOpenMusic)
	{
		mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������
	}

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);	//���漴�������ǵ�ͼƬ

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	TransparentBlt( dstDC, Owe.iX, Owe.iY, 30, 40, srcDC, 0, 0, 30, 40,  RGB(0,255,0));		
	FlushBatchDraw();

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire = getch();

		switch( Owe.iDire )
		{
			case UP:
				SetWorkingImage( &imgbkNum);	

				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					SetWorkingImage();	
					Owe.iY-=2;
					MoveImage( &imgbkNum);
				}

				else
				{
					SetWorkingImage();
					MoveImage( &imgbkNum);
				}

				break;

			case DOWN:
				//�������ɫֵ
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if(getpixel( Owe.iX+15, Owe.iY+2+30) == lkclore)
					{
						if(iOpenMusic)
						{
							mciSendString("stop BackMusic2", NULL, 0, NULL);
							mciSendString("play OpenDoor from 0", NULL, 0, NULL);
						}

						AlterScreen();

						if(iOpenMusic)
							mciSendString("play BackMusic1 repeat", NULL, 0, NULL); 

						return ;
					}

					Owe.iY+=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case LEFT:
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
				{
					Owe.iX-=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case RIGHT:
				if(getpixel( Owe.iX+2+24, Owe.iY+34)!= BanClore)
				{
					Owe.iX+=2;
					MoveImage( &imgbkNum);
				}

				else
					MoveImage( &imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return;
}

/////////////////////����ս��1//////////////
int ClubZhanChang_1(int iAlwayPet)
{
	IMAGE img,imgkbNum,imgBall;
	IMAGE imgMenu,imgMenu2[4],imgMenu1;
	IMAGE imgShow,imgShow1[7];
	IMAGE imgNotRun;
	IMAGE imgWin,imgWin1[2];

	struct Pet OtherPet;	
	int   iX=0,iX1=0,iY1;
	int   iPeople,iPetNum=0,iFlag=0;
	int   i,iKey,iOtherPetNum=1;
	char  cNum[8];
	char  cWord[40]="ս��ʤ����n  ��ϲ������n  ���";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC ;

	loadimage(&img, "ͼƬ/��ͼ/����ս��1.bmp");  //���ص�ͼ640*480
	loadimage(&imgBall,"ͼƬ/������.bmp",10,10);
	loadimage(&imgShow,"ͼƬ/�������.bmp");
	loadimage(&imgMenu,"ͼƬ/ս���˵�.bmp");
	loadimage(&imgMenu1,"ͼƬ/ѡ���.bmp");
	loadimage(&imgNotRun,"ͼƬ/��������.bmp");
	loadimage(&imgWin,"ͼƬ/ʤ��.bmp");

	SetWorkingImage(&imgWin);
	for(i=0;i<2;i++)
		getimage(&imgWin1[i],0,i*60,180,60);

	SetWorkingImage(&imgShow);
	for(i=0;i<7;i++)
		getimage(&imgShow1[i],i*67,0,67,99);

	SetWorkingImage(&imgMenu1);
	for(i=0;i<4;i++)
		getimage(&imgMenu2[i],i*45,0,45,20);

	SetWorkingImage();

	if(iOpenMusic)
	{
		mciSendString("stop BackMusic2", NULL, 0, NULL);
		mciSendString("play BattleMusic repeat", NULL, 0, NULL); //ѭ������
	}

	//�����������ͼƬ�;�����
	iPeople=rand()%4;
	OtherPet.iNum=rand()%40;

	while(TRUE)	//�����ƶ�
	{
		if(iX1>=90)	break;

		iX1+=2;
		if(++iFlag>2)	iFlag=0;

		BeginBatchDraw();
		putimage(0,0,&img);
		srcDC = GetImageHDC( &imgOwe[1][iFlag]);
		TransparentBlt( dstDC, iX1, 210, 30, 40, srcDC, 0, 0, 30, 40,  RGB(0,255,0));
		srcDC = GetImageHDC( &imgOtherPeople[iPeople][0][iFlag]);
		TransparentBlt( dstDC, 640-iX1, 210, 30, 40, srcDC, 0, 0, 30, 40,  RGB(0,255,0));
		FlushBatchDraw();

		Sleep(70);
	}

	getimage(&imgkbNum,0,0,640,480);
	srcDC = GetImageHDC( &imgBall);

	while(TRUE)		//���ƶ�
	{
		if(iX1>=205)	break;
		iX1+=2;

		BeginBatchDraw();
		putimage(0,0,&imgkbNum);

		TransparentBlt( dstDC, iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));
		TransparentBlt( dstDC, 640-iX1, 230, 10,10, srcDC, 0, 0, 10,10,  RGB(0,255,0));
		FlushBatchDraw();
		Sleep(8);
	}
//	putimage(0,0,&imgkbNum);

	for(i=0;i<7;i++)
	{
		srcDC = GetImageHDC( &imgShow1[i]);
		BeginBatchDraw();
		putimage(0,0,&imgkbNum);

		TransparentBlt( dstDC, 173, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
		TransparentBlt( dstDC, 401, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
		FlushBatchDraw();
		Sleep(100);
	}

	for(i=0;i<3;i++)//ѡ���������
		if(man.pet[i].iPH)
		{
			iPetNum=i;
			break;
		}

	BeginBatchDraw();//��ʾ����
	putimage(0,0,&imgkbNum);
	srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
	TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
	
	srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
	TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
	FlushBatchDraw();
	EndBatchDraw();
	
	//Ϊ���־��鸳ֵ
	OtherPet.iGrade=man.pet[0].iGrade;
	for(i=1;i<3;i++) 
		if(man.pet[i].iGrade > OtherPet.iGrade)
			OtherPet.iGrade=man.pet[i].iGrade;
	OtherPet.iGrade -= rand()%3;
	if(OtherPet.iGrade<=0)
		OtherPet.iGrade=2;

	OtherPet.iPH=OtherPet.iAlwayPH=(OtherPet.iGrade-1)*6+30;
	OtherPet.iAtt=(OtherPet.iGrade-1)*3+14;
	OtherPet.iDef=(OtherPet.iGrade-1)*2+10;

	while(TRUE) //ս������
	{
		BeginBatchDraw();

		putimage(0,375,&imgMenu);
		switch( iX)
		{
			case 0:
				putimage(8,409,&imgMenu2[iX]);
				break;
			case 1:
				putimage(62,409,&imgMenu2[iX]);
				break;
			case 2:
				putimage(8,435,&imgMenu2[iX]);
				break;
			case 3:
				putimage(62,435,&imgMenu2[iX]);
				break;
			default :
				break;
		}

		if(man.pet[iPetNum].iPH <= (man.pet[iPetNum].iAlwayPH)/4 ) //HPС�ڵ���1/4ʱ�Ժ�ɫ
			setcolor(RED);
		else
			setcolor(BLACK);

		outtextxy(120,380,cPetName[man.pet[iPetNum].iNum]); //��ʾ������Ϣ
		sprintf(cNum,"%d��",man.pet[iPetNum].iGrade);//�ȼ�
		outtextxy(210,380,cNum);

		sprintf(cNum,"%d",man.pet[iPetNum].iPH);//HP
		outtextxy(165,415,cNum);
		sprintf(cNum,"%d",man.pet[iPetNum].iAlwayPH);
		outtextxy(215,415,cNum);

		sprintf(cNum,"%d",man.pet[iPetNum].iExp);//MP
		outtextxy(165,442,cNum);
		sprintf(cNum,"%d",man.pet[iPetNum].iAlwayExp);
		outtextxy(215,442,cNum);


		setcolor(BLACK);
		//��ʾ���־�����Ϣ
		outtextxy(475,380,cPetName1[OtherPet.iNum]); 
		sprintf(cNum,"%d��",OtherPet.iGrade); //�ȼ�
		outtextxy(565,380,cNum);

		sprintf(cNum,"%d",OtherPet.iAlwayPH); //HP
		outtextxy(565,415,cNum);

		sprintf(cNum,"%d",OtherPet.iPH);
		outtextxy(520,415,cNum);	
		FlushBatchDraw();
						
		DeviceKBBuf();
		iKey=getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey )//ѡ�����
		{
			case UP:
				if(iX+2>=4)
					iX-=2;
				else
					iX+=2;
				break;

			case DOWN:
				if(iX+2>=4)
					iX-=2;
				else
					iX+=2;
				break;

			case LEFT:
				if(iX%2==0)
					iX+=1;
				else
					iX-=1;
				break;

			case RIGHT:
				if(iX%2==0)
					iX+=1;
				else
					iX-=1;
				break;

			case ENTER:
				switch( iX )
				{
					case 0:	//����

						iX1=176;
						for(i=1;i<=10;i++)
						{
							BeginBatchDraw();//������ǰ�ƶ�
							putimage(0,0,&imgkbNum);
							srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
							TransparentBlt( dstDC, iX1, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							
							srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
							TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							FlushBatchDraw();

							iX1+=2;
							Sleep(50);
						}

						if(rand()%10>2)	//������
						{
							KitShow(404, 185);

							for(i=1;i<=10;i++)
							{
								iY1=185;
								if(i%2==0)
									iY1+=4;
								else
									iY1-=4;

								BeginBatchDraw();//����ʱ�Է��������
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
								TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, iY1, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();

								Sleep(50);
							}
							

							if( (man.pet[iPetNum].iAtt-OtherPet.iDef) <=0 )
							{
								OtherPet.iPH-=1;
								sprintf(cNum,"-%d",1);
							}
							else
							{
								OtherPet.iPH-=(man.pet[iPetNum].iAtt-OtherPet.iDef);
								sprintf(cNum,"-%d",(man.pet[iPetNum].iAtt-OtherPet.iDef));
							}

							setcolor(RED);
							outtextxy(400, 200, cNum);	
							FlushBatchDraw();
							Sleep(300);
							setcolor(BLACK);

							man.pet[iPetNum].iExp+=OtherPet.iGrade*2;	//��þ���ֵ
							if(man.pet[iPetNum].iExp >= man.pet[iPetNum].iAlwayExp)
								AdvancePet(iPetNum);//�ȼ�����

							if( OtherPet.iPH<=0) //�Է�����HPֵС��0ʱ
							{
								if(iOtherPetNum==iAlwayPet)//�Է����о���HP��Ϊ0ʱʤ��
								{

									if(iOpenMusic)
									{	
										mciSendString("stop BattleMusic", NULL, 0, NULL);
										mciSendString("play Win from 0", NULL, 0, NULL);
									}

									Sleep(800);

									srcDC = GetImageHDC( &imgWin1[0]);
									TransparentBlt( dstDC, 230, 210, 180, 60, srcDC, 0, 0, 180, 60,  RGB(0,255,0));
									FlushBatchDraw();
									EndBatchDraw();

									sprintf(cNum,"%4d",iAlwayPet*(OtherPet.iGrade*2+10)); //�����Ӧ���
									strcat(cWord,cNum);
									strcat(cWord,"��ң�����");
									man.iMoney+=iAlwayPet*(OtherPet.iGrade*2+10);
									Road_2(cWord);

									if(iOpenMusic)
										mciSendString("play BackMusic2 repeat", NULL, 0, NULL); //ѭ������

									return WIN;
								}

								iOtherPetNum++;

								OtherPet.iNum=rand()%40;//������ɾ���

								//Ϊ���־��鸳ֵ
								OtherPet.iGrade=man.pet[0].iGrade;
								for(i=1;i<3;i++) 
									if(man.pet[i].iGrade>man.pet[i-1].iGrade)
										OtherPet.iGrade=man.pet[i].iGrade;
								OtherPet.iGrade += rand()%2;

								OtherPet.iPH=OtherPet.iAlwayPH=(OtherPet.iGrade-1)*6+30;
								OtherPet.iAtt=(OtherPet.iGrade-1)*3+14;
								OtherPet.iDef=(OtherPet.iGrade-1)*2+10;

								iX1=90;
								while(TRUE)		//���ƶ�
								{
									if(iX1>=205)	break;
									iX1+=2;

									BeginBatchDraw();
									putimage(0,0,&imgkbNum);
									srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
									TransparentBlt( dstDC, 176, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
									srcDC = GetImageHDC( &imgBall);
									TransparentBlt( dstDC, 640-iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));

									FlushBatchDraw();
									Sleep(8);
								}

								for(i=0;i<7;i++)
								{
									BeginBatchDraw();
									putimage(0,0,&imgkbNum);	
									srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
									TransparentBlt( dstDC, 176, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
									srcDC = GetImageHDC( &imgShow1[i]);
									TransparentBlt( dstDC, 401, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
									FlushBatchDraw();
									Sleep(100);
								}

								BeginBatchDraw(); //��ʾ����
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
								TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();
							
							}
						}

						Sleep(500);

				BEGIN2:
						iX1=404;//�Է�����

						for(i=1;i<=10;i++)
						{
							BeginBatchDraw();//�Է��ƶ�����
							putimage(0,0,&imgkbNum);
							srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
							TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							
							srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
							TransparentBlt( dstDC, iX1, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							FlushBatchDraw();

							iX1-=2;
							Sleep(50);
						}

						if( rand()%10>2 ) //�Է��������и���
						{
							KitShow(176, 185);

							for(i=1;i<=10;i++)
							{
								iY1=185;
								if(i%2==0)
									iY1+=4;
								else
									iY1-=4;

								BeginBatchDraw(); //�������
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
								TransparentBlt( dstDC, 176, iY1 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();

								Sleep(50);
							}


							if((OtherPet.iAtt-man.pet[iPetNum].iDef) <= 0)
							{
								man.pet[iPetNum].iPH-=1;
								sprintf(cNum,"-%d",1);
							}
							else 
							{							
								man.pet[iPetNum].iPH-=(OtherPet.iAtt-man.pet[iPetNum].iDef);	
								sprintf(cNum,"-%d",(OtherPet.iAtt-man.pet[iPetNum].iDef));
							}

							setcolor(RED);
							outtextxy(240, 200, cNum);	
							FlushBatchDraw();
							Sleep(300);
							setcolor(BLACK);

							if(man.pet[iPetNum].iPH<=0)	//����HPֵС��0ʱ�Զ�������������
							{
								man.pet[iPetNum].iPH=0;

								for(i=0;i<3;i++)	//�Զ�ѡ���ܳ�ս�ľ���
									if(man.pet[i].iPH)
									{
										iPetNum=i;
										iX1=90;
						
										while(TRUE)		//���ƶ�
										{
											if(iX1>=205)	break;
											iX1+=2;

											BeginBatchDraw();
											putimage(0,0,&imgkbNum);
											srcDC = GetImageHDC( &imgBall);
											TransparentBlt( dstDC, iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));
											srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
											TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
											FlushBatchDraw();
											Sleep(8);
										}

										for(i=0;i<7;i++)
										{
											BeginBatchDraw();
											putimage(0,0,&imgkbNum);
											srcDC = GetImageHDC( &imgShow1[i]);
											TransparentBlt( dstDC, 173, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
											srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
											TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
											FlushBatchDraw();
											Sleep(100);
										}

										BeginBatchDraw(); //��ʾ����
										putimage(0,0,&imgkbNum);
										srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
										TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
										srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
										TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
										FlushBatchDraw();

										break;
									}

								if(i==3)	//���о���HP��Ϊ0ʱʧ��
								{
									if(iOpenMusic)
									{
										mciSendString("stop BattleMusic", NULL, 0, NULL);
										mciSendString("play Lose from 0", NULL, 0, NULL);
									}

									srcDC = GetImageHDC( &imgWin1[1]);
									TransparentBlt( dstDC, 230, 210, 180, 60, srcDC, 0, 0, 180, 60,  RGB(0,255,0));
									EndBatchDraw();
									Sleep(4000);

									if(iOpenMusic)
									{
										mciSendString("stop Lose",NULL,0,NULL);
										mciSendString("play BackMusic2 repeat", NULL, 0, NULL);
									}
								
									return DIE;
								}

								continue;
							}
						}

						BeginBatchDraw();//�ƶ�����
						putimage(0,0,&imgkbNum);
						srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
						TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
						
						srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
						TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
						FlushBatchDraw();
						break;

					case 1: //����
						BeiBaoMenu();
						continue;
						break;

					case 2: //�ֶ���������
						i=ChangePet();

						if(i>=0 && i!=iPetNum)	
						{
							iPetNum=i;
							iX1=90;
						
							while( TRUE)		//���ƶ�
							{
								if(iX1>=205)	break;
								iX1+=2;

								BeginBatchDraw();
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgBall);
								TransparentBlt( dstDC, iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();
								Sleep(8);
							}

							for(i=0;i<7;i++)
							{
								BeginBatchDraw();
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgShow1[i]);
								TransparentBlt( dstDC, 173, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();
								Sleep(100);
							}
	
							BeginBatchDraw();	//��ʾ����
							putimage(0,0,&imgkbNum);
							srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
							TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
							TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							FlushBatchDraw();
	
							goto BEGIN2;
						}
						break;
	
					case 3: //����
						BeginBatchDraw();
						putimage(290,409,&imgNotRun);
						FlushBatchDraw();
						Sleep(500);
						goto BEGIN2;
	
						break;
	
					default :
						break;
				}
	
				    break;

				default :
					break;
			}	
		}

	return DIE;
}

////////////��������////////////////
void KitShow(int iX,int iY)

{
	IMAGE imgbk;
	int i,j,iNum;
	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;

	getimage(&imgbk,iX,iY,70,90);

	if(iOpenMusic)
		mciSendString("play Battle from 0", NULL, 0, NULL);

	iNum=rand()%8;
	for(j=1;j<=2;j++)
	{
		for(i=0;i<4;i++)
		{
			BeginBatchDraw();
			putimage(iX,iY,&imgbk);
			srcDC = GetImageHDC( &imgBattle[iNum][i]);
			TransparentBlt( dstDC, iX, iY, 70,90, srcDC, 0, 0, 70,90,  RGB(0,255,0));
			FlushBatchDraw();
			Sleep(150);
		}
	}

	EndBatchDraw();

	if(iOpenMusic)
		mciSendString("stop Battle", NULL, 0, NULL);

	putimage(iX,iY,&imgbk);
	return;
}

///////////////ս���и�������////////////
int ChangePet()
{
	IMAGE img,img1,imgbk;
	int iX=0,i;
	int iKey;
	char cNum[8];
	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;

	setcolor(RED);
	setfont(18,0,"��Բ");

	loadimage(&img,"ͼƬ/���鱳����.bmp");
	loadimage(&img1,"ͼƬ/����ѡ��.bmp");
	getimage(&imgbk,0,275,220,92);

	BeginBatchDraw();
	putimage(0,275,&img);
	putimage(10,280,&img1);

	for(i=0;i<3;i++)	//��ʾ����
	{		
		srcDC = GetImageHDC( &imgPet[man.pet[i].iNum]);
		TransparentBlt( dstDC, i*70, 275, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
	}
	sprintf(cNum,"HP:%d",man.pet[iX].iPH);
	outtextxy(15,340,cNum);
	FlushBatchDraw();

	while(TRUE)
	{
		iKey=getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch(iKey)
		{
			case LEFT:
				if(--iX<0)
					iX=2;
				BeginBatchDraw();
				putimage(0,275,&img);
				putimage(iX*70+10,280,&img1);
				for(i=0;i<3;i++)
				{		
					srcDC = GetImageHDC(&imgPet[man.pet[i].iNum]);
					TransparentBlt( dstDC, i*70, 275, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
				}
				sprintf(cNum,"HP:%d",man.pet[iX].iPH);
				outtextxy(iX*70+15,340,cNum);
				FlushBatchDraw();

				break;

			case RIGHT:
				if(++iX>2)
					iX=0;
				BeginBatchDraw();
				putimage(0,275,&img);
				putimage(iX*70+10,280,&img1);
				for(i=0;i<3;i++)
				{		
					srcDC = GetImageHDC( &imgPet[man.pet[i].iNum]);
					TransparentBlt( dstDC, i*70, 275, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
				}
				sprintf(cNum,"HP:%d",man.pet[iX].iPH);
				outtextxy(iX*70+15,340,cNum);
				FlushBatchDraw();

				break;

			case SPACE:
				EndBatchDraw();
				putimage(0,275,&imgbk);
				setcolor(BLACK);
				setfont(20,0,"��Բ");
				return -1;	//����
				break;

			case ENTER:
				if(man.pet[iX].iPH>0)
				{
					EndBatchDraw();
					putimage(0,275,&imgbk);
					setcolor(BLACK);
					setfont(20,0,"��Բ");
					return iX;	//���ؾ�����
				}
				break;

			default:
				break;
		}

	}

	return iX;
}

/////////////////�����������ݱ仯/////////////////
void AdvancePet(int iPetNum)
{
	IMAGE imgbk;
	int iY;

	getimage(&imgbk,176, 135,130,70);

	if(iOpenMusic)
		mciSendString("play Advance from 0", NULL, 0, NULL);	

	setcolor(RED);
	for(iY=185;iY>=150;iY-=5)
	{
		BeginBatchDraw();
		putimage(176,135,&imgbk);
		outtextxy(190, iY,"����");
		FlushBatchDraw();
		Sleep(100);
	}
	setcolor(BLACK);

	man.pet[iPetNum].iExp-=man.pet[iPetNum].iAlwayExp; //MP
	if(man.pet[iPetNum].iExp<0)
		man.pet[iPetNum].iExp=0;

	man.pet[iPetNum].iAlwayExp+=man.pet[iPetNum].iGrade*3;

	man.pet[iPetNum].iAlwayPH+=6;	//HP
	man.pet[iPetNum].iPH=man.pet[iPetNum].iAlwayPH;

	man.pet[iPetNum].iAtt+=3;
	man.pet[iPetNum].iDef+=2;

	man.pet[iPetNum].iGrade++;

	putimage(176,135,&imgbk);
	EndBatchDraw();

	return;
}

////////////////////����������//////////////////
int  NanToBeiMap()
{
	IMAGE img,imgbkNum;
	COLORREF NowClore;
	int iY;
	int i,iFlag=0;
	int iStep,iStepNum=0;//��ǲ�����

	char cNum1[]="����--����������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/��������ͼ.bmp");  //���ص�ͼ640*1200

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	if(	Owe.iOldY>240)
		iY=-720;
	else
		iY=0;
	putimage(0,iY,&img);



	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);


	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();

	iStep=rand()%100+100;

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if(DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=520;
				Owe.iY=430;
				Owe.iNewDire=2;

				return NANNING;
			}

			putimage(0,iY,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					NowClore = getpixel(15,30);

					if( NowClore == RoadClore)	//����·��
					{
						SetWorkingImage();
						MoveImage( &imgbkNum);
						Road_1(cNum1);
					}

					else if( NowClore == lkclore)//����·��
					{
						SetWorkingImage();
						Owe.iX=520;
						Owe.iY=430;
						Owe.iNewDire=2;

						return NANNING;
					}
					else if( NowClore != RoadClore)
					{
						SetWorkingImage();

						if(Owe.iY<=240 && iY<0)//����ͼ�ƶ�
						{
							for(i=1;i<=2;i++)
							{
								iY+=1;

								BeginBatchDraw();

								putimage(0,iY,&img);
								getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
								srcDC = GetImageHDC( &imgOwe[2][iFlag++]);
								TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

								FlushBatchDraw();
								EndBatchDraw();

								if(iFlag>=3) iFlag=0;
						    
							}

						}

						else
						{
							Owe.iY-=2;
							MoveImage( &imgbkNum);
						}
					}

					else
						SetWorkingImage();
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
				{
					if( getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore)
					{
						Owe.iX=45;
						Owe.iY=5;
						Owe.iNewDire=3;
						//������һ�ŵ�ͼ
						return BEIHAI;
					}

					else if(Owe.iY>=240 && iY>-720)
					{
						for(i=1;i<=2;i++)
						{
							iY-=1;
							BeginBatchDraw();

							putimage(0,iY,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[3][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
							
						}
					}

					else
					{
						Owe.iY+=2;
						MoveImage( &imgbkNum);
					}

				}

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
					Owe.iX-=2;

				MoveImage(&imgbkNum);

				break;

			case RIGHT:
				iStepNum++;
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
					Owe.iX+=2;

				MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}

//////////////////������ͼ/////////////////////
int BeiHaiMap()
{
	IMAGE img,imgbkNum;
	COLORREF LNowClore,RNowClore;
	int i,iFlag=0,iFlag1=0;

	char cNum1[]="������n  λ�ڹ���׳���������϶ˣ����ٱ����塣n  ȫ���ϱ���11���������20���";
	char cNum2[]="�̵�n  ���Թ�����Ʒ������n  �Լ���Ϸ������";
	char cNum3[]="����ʾn  һ��һ��������  �۸���򣡣���n  ��ϵ�绰��110 ";
	char cNum4[]="�����е���n  ��ս��һ�����о���HPֵ��Ϊ�㽫������ս������n  ��ʾ��ս������׼��������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;
	
	loadimage(&img, "ͼƬ/��ͼ/������ͼ.bmp");  //���ص�ͼ640*480

	putimage(0,0,&img);
	SetOthrePeopleXY(400,180);

BEGIN:
	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч


	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		while(kbhit())
		{
			Owe.iDire=getch();

    		switch(Owe.iDire)
			{
				case UP:
					LNowClore=getpixel( Owe.iX+5, Owe.iY-2+ 35);
					RNowClore=getpixel( Owe.iX+22, Owe.iY-2+ 35);
						
					if( LNowClore == HomeClore && RNowClore == HomeClore)	//�������
					{										
						OtherHomeMap_1();

						Owe.iX= 375;
						Owe.iY= 310;
						Owe.iNewDire=3;	
		
						goto BEGIN;
					}

					else if( LNowClore == ShopClore &&  RNowClore == ShopClore)	//�����̵�
					{
						ShopMap();

						Owe.iX=197;
						Owe.iY=230;
						Owe.iNewDire=3;

						goto BEGIN;
					}
					else if( LNowClore == ClubClore &&  RNowClore == ClubClore)	//�������1
					{
						for(i=0;i<3;i++) //�鿴�Ƿ��пɳ�ս����
							if(man.pet[i].iPH)
								break;
						if(i==3)
						{
							Road_2("��ʾ��n  û�п���ս���ľ��飡����n  ��Ϊ����伢�ɣ�����");
							goto BEGIN;
						}

						ClubMap_2();

						Owe.iX=483;
						Owe.iY=100;
						Owe.iNewDire=3;
						goto BEGIN;
					}

					else if( LNowClore == RoadClore || RNowClore == RoadClore)	//����·��
					{
						if(Owe.iX<140)
							Road_1(cNum1);
						else if(Owe.iX<290)
							Road_1(cNum2);
						else if(Owe.iX<380)
							Road_1(cNum3);
						else 
							Road_1(cNum4);
					}

					else if( LNowClore == lkclore)//·��
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							goto BEGIN;
						}

						Owe.iX=455;
						Owe.iY=440;
						Owe.iNewDire=2;
						return NANtoBEI;
					}

					else if( LNowClore !=BanClore &&  RNowClore !=BanClore &&  LNowClore != RoadClore)
						Owe.iY-=2;

					iFlag1++;

					break;

				case DOWN:
					if(getpixel( Owe.iX+5, Owe.iY+ 2+ 35)!= BanClore && getpixel( Owe.iX+20, Owe.iY+2+35)!= BanClore)
						Owe.iY+=2;

					iFlag1++;

					break;

				case LEFT:
					if(getpixel( Owe.iX-2+5, Owe.iY+35) == lkclore)
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							goto BEGIN;
						}

						Owe.iX=605;
						Owe.iY=80;
						Owe.iNewDire=0;

						return CROSS_1;
					}
					else if(getpixel( Owe.iX-2+5, Owe.iY+35)!= BanClore)
						Owe.iX-=2;
					iFlag1++;

					break;

				case RIGHT:
					if( getpixel(Owe.iX+2+20,Owe.iY+35)!= BanClore)
						Owe.iX+=2;
					iFlag1++;

					break;

				case SPACE:
					Menu2();
					break;

				default :
					break;
			}
		}
		if(iFlag1>=3)	iFlag1=0;

		OthrePeopleMove(&img,0,0,iFlag1);
	}

	return HOME;
}

//////////////����������·��/////////////////////
int BeiToCrossMap()
{
	IMAGE img,imgbkNum;
	COLORREF NowClore;
	int iFlag=0;
	int iStep,iStepNum=0;	//��ǲ�����
	char cNum1[]="����--����--����";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/��������ͼ.bmp");  //���ص�ͼ640*480

	iStep=rand()%100+100;

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));		
	FlushBatchDraw();

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();


		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if(DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=10;
				Owe.iY=320;
				Owe.iNewDire=1;
				return BEIHAI;
			}

			putimage(0,0,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30) != BanClore)
				{
					NowClore = getpixel(15,30);
					if( NowClore == RoadClore)	//����·��
					{
						SetWorkingImage();
						MoveImage( &imgbkNum);
						Road_1(cNum1);
					}

					else
					{
						SetWorkingImage();
						Owe.iY-=2;
						MoveImage( &imgbkNum);
					}
				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34) == lkclore && getpixel( Owe.iX+24, Owe.iY+2+34) == lkclore)
				{
					Owe.iX=460;
					Owe.iY=5;
					Owe.iNewDire=3;
					return CROSS_2;
				}
				else if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
					Owe.iY+=2;

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34)!= BanClore)
					Owe.iX-=2;

				MoveImage(&imgbkNum);

				break;

			case RIGHT:	
				iStepNum++;
				if(getpixel( Owe.iX+2+24, Owe.iY+34) == lkclore)
				{
					if(Owe.iY<150)
					{
						Owe.iX=10;
						Owe.iY=320;
						Owe.iNewDire=1;
						return BEIHAI;
					}
					else
					{
						Owe.iX=15;
						Owe.iY=105;
						Owe.iNewDire=1;
						return WUZHOU;
					}
				}
				else if(getpixel( Owe.iX+2+24, Owe.iY+34)!= BanClore)
					Owe.iX+=2;

				MoveImage(&imgbkNum);

				break;

			case SPACE:
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}

////////////////////���ݵ�ͼ/////////////////////
int WuZhouMap()
{
	IMAGE img,imgbkNum;
	COLORREF LNowClore,RNowClore;
	int i,iFlag=0,iFlag1=0;

	char cNum1[]="�̵�n  ���Թ�����Ʒ������n  �Լ���Ϸ������";
	char cNum2[]="������n  λ�ڹ���׳�����������������ڹ㶫���Ͻ����֣�������ۡ�n  ����������������߽磬�ǹ��������š�";
	char cNum3[]="�����е���n  ��ս��һ�����о���HPֵ��Ϊ�㽫������ս������n  ��ʾ��ս������׼��������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC;
	
	loadimage(&img, "ͼƬ/��ͼ/���ݵ�ͼ.bmp");  //���ص�ͼ640*480

	putimage(0,0,&img);
	SetOthrePeopleXY(460,150);

BEGIN:
	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	putimage(0,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);

	srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0));//����ɫ����Ϊ��ɫ 		
	FlushBatchDraw();// ʹ GDI ������Ч


	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		while(kbhit())
		{
			Owe.iDire=getch();

    		switch(Owe.iDire)
			{
				case UP:
					LNowClore=getpixel( Owe.iX+5, Owe.iY-2+ 35);
					RNowClore=getpixel( Owe.iX+22, Owe.iY-2+ 35);				
					if(LNowClore == HomeClore && RNowClore == HomeClore )	//�������
					{					
						//��ͼ��ͬ���겻ͬ					
						OtherHomeMap_2();

						Owe.iX= 345;
						Owe.iY= 110;
						Owe.iNewDire=3;	
		
						goto BEGIN;
					}

					else if( LNowClore == ShopClore &&  RNowClore == ShopClore)	//�����̵�
					{
						ShopMap();

						Owe.iX=100;
						Owe.iY=80;
						Owe.iNewDire=3;

						goto BEGIN;
					}
					else if( LNowClore == ClubClore &&  RNowClore == ClubClore)	//�������1
					{
						for(i=0;i<3;i++) //�鿴�Ƿ��пɳ�ս����
							if(man.pet[i].iPH)
								break;
						if(i==3)
						{
							Road_2("��ʾ��n  û�п���ս���ľ��飡����n  ��Ϊ����伢�ɣ�����");
							goto BEGIN;
						}

						ClubMap_2();

						Owe.iX=345;
						Owe.iY=270;
						Owe.iNewDire=3;
						goto BEGIN;
					}

					else if( LNowClore == RoadClore || RNowClore == RoadClore)	//����·��
					{
						if(Owe.iX<100)
							Road_1(cNum1);
						else if(Owe.iX<200)
							Road_1(cNum2);
						else
							Road_1(cNum3);
					}

					else if(LNowClore == lkclore)
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							goto BEGIN;
						}

						Owe.iX=280;
						Owe.iY=430;
						Owe.iNewDire=2;
						return LIUtoWU;
					}

					else if( LNowClore !=BanClore &&  RNowClore !=BanClore && LNowClore != RoadClore )
						Owe.iY-=2;

					iFlag1++;

					break;

				case DOWN:
					if(getpixel( Owe.iX+5, Owe.iY+ 2+ 35) == lkclore && getpixel( Owe.iX+22, Owe.iY+2+35) == lkclore)
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							goto BEGIN;
						}

						Owe.iX=530;
						Owe.iY=5;
						Owe.iNewDire=3;
						return WUtoFU;
					}
					else if(getpixel( Owe.iX+5, Owe.iY+ 2+ 35)!= BanClore && getpixel( Owe.iX+22, Owe.iY+2+35)!= BanClore)
						Owe.iY+=2;

					iFlag1++;

					break;

				case LEFT:
					if(getpixel( Owe.iX-2+5, Owe.iY+35) == lkclore)
					{
						if(DetectionHP())
						{
							Road_2("��ʾ��n  ��ȥΣ�����أ�����n  �ȸ�����伢�ɣ�����");
							goto BEGIN;
						}

						Owe.iX=605;
						Owe.iY=400;
						Owe.iNewDire=0;
						return CROSS_1;
					}
					else if(getpixel( Owe.iX-2+5, Owe.iY+35)!= BanClore)
						Owe.iX-=2;
					iFlag1++;

					break;

				case RIGHT:
					if( getpixel(Owe.iX+2+22,Owe.iY+35)!= BanClore)
						Owe.iX+=2;
					iFlag1++;

					break;

				case SPACE:
					Menu2();
					break;

				default :
					break;
			}
		}
		if(iFlag1>=3)	iFlag1=0;

		OthrePeopleMove(&img,0,0,iFlag1);
	}

	return HOME;
}

/////////////////////����������//////////////////
int WuToFuMap()
{
	IMAGE img,imgbkNum;
	int iX;
	int i,iFlag=0;
	int iStep,iStepNum=0;	//��ǲ�����

	char cNum1[]="���硪������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/��������ͼ.bmp");  //���ص�ͼ1000*480

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	if(	Owe.iOldX>240)
		iX=-360;
	else
		iX=0;

	putimage(iX,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);


	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();
	iStep=rand()%100+100;

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();

		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if(DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=145;
				Owe.iY=430;
				Owe.iNewDire=2;

				return WUZHOU;
			}

			putimage(iX,0,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					if(getpixel(15,30)== lkclore)//����·��
					{
						SetWorkingImage();
						Owe.iX=145;
						Owe.iY=430;
						Owe.iNewDire=2;

						return WUZHOU;
					}

					else
					{
						SetWorkingImage();
						Owe.iY-=2;
						MoveImage( &imgbkNum);		
					}

				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
					Owe.iY+=2;

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34) == lkclore)
				{
					Owe.iX=605;
					Owe.iY=350;
					Owe.iNewDire=2;

					return CROSS_2;
				}

				else if(getpixel( Owe.iX-2+5, Owe.iY+34) != BanClore)
				{
					if(iX<0 && Owe.iX<=240)	//����ͼ�ƶ�
					{
						for(i=1;i<=2;i++)
						{
							iX+=1;

							BeginBatchDraw();

							putimage(iX,0,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[0][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						
						}
					}

					else
					{
						Owe.iX-=2;
						MoveImage(&imgbkNum);
					}
				}

				else
					MoveImage(&imgbkNum);

				break;

			case RIGHT:
				iStepNum++;
				if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
				{
					if(iX>-360 && Owe.iX>=240)//����ͼ�ƶ�
					{
						for(i=1;i<=2;i++)
						{
							iX-=1;

							BeginBatchDraw();

							putimage(iX,0,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[1][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						}
					}

					else
					{
						Owe.iX+=2;
						MoveImage(&imgbkNum);
					}
				}
				else
					MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}

///////////////////����·��ͼ///////////////////////
int CrossMap()
{
	IMAGE img,imgbkNum;
	int iX;
	int i,iFlag=0;
	int iStep,iStepNum=0;	//��ǲ�����

	char cNum1[]="���硪������";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC = GetImageHDC(&imgOwe[Owe.iNewDire][0]);
	
	loadimage(&img, "ͼƬ/��ͼ/����·��ͼ.bmp");  //���ص�ͼ1000*480

	Owe.iOldX=Owe.iX;
	Owe.iOldY=Owe.iY;

	if(	Owe.iOldX>240)
		iX=-360;
	else
		iX=0;

	putimage(iX,0,&img);

	getimage( &imgbkNum, Owe.iOldX, Owe.iOldY, 30, 40);


	// ʹ�� Windows GDI �����������
	TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 		
	FlushBatchDraw();
	iStep=rand()%100+100;

	while(TRUE)   //�����ƶ�����
	{
		Sleep(30);

		Owe.iDire=getch();


		if(iStepNum == iStep)
		{
			iStepNum=0;

			YeWaiZhanchang_1();	

			if(DetectionHP())	//���о���HP��Ϊ0ʱ
			{
				Owe.iX=605;
				Owe.iY=200;
				Owe.iNewDire=0;
				return FUSUI;
			}

			putimage(iX,0,&img);
			iStep=rand()%100+100;
		}

		switch(Owe.iDire)
		{
			case UP:
				iStepNum++;
				SetWorkingImage(&imgbkNum);
				if(getpixel(5, 30)!=BanClore && getpixel(24, 30)!=BanClore)
				{
					if(getpixel(15,30)== lkclore)//����·��
					{
						SetWorkingImage();
						Owe.iX=20;
						Owe.iY=445;
						Owe.iNewDire=2;

						return CROSS_1;
					}

					else
					{
						SetWorkingImage();
						Owe.iY-=2;
						MoveImage( &imgbkNum);		
					}

				}

				else
				{
					SetWorkingImage();
					MoveImage(&imgbkNum);
				}

				break;

			case DOWN:
				iStepNum++;
				if(getpixel( Owe.iX+5, Owe.iY+ 2+ 34)!= BanClore && getpixel( Owe.iX+24, Owe.iY+2+34)!= BanClore)
					Owe.iY+=2;

				MoveImage(&imgbkNum);

				break;

			case LEFT:
				iStepNum++;
				if(getpixel( Owe.iX-2+5, Owe.iY+34) == lkclore)
				{
					Owe.iX=605;
					Owe.iY=200;
					Owe.iNewDire=0;

					return FUSUI;
				}

				else if(getpixel( Owe.iX-2+5, Owe.iY+34) != BanClore)
				{
					if(iX<0 && Owe.iX<=240)//����ͼ�ƶ�
					{
						for(i=1;i<=2;i++)
						{
							iX+=1;

							BeginBatchDraw();

							putimage(iX,0,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[0][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						
						}
					}

					else
					{
						Owe.iX-=2;
						MoveImage(&imgbkNum);
					}
				}

				else
					MoveImage(&imgbkNum);

				break;

			case RIGHT:
				iStepNum++;
				if(getpixel(Owe.iX+2+24,Owe.iY+34) == lkclore)
				{
					Owe.iX=15;
					Owe.iY=210;
					Owe.iNewDire=1;

					return WUtoFU;
				}
				else if( getpixel(Owe.iX+2+24,Owe.iY+34)!= BanClore)
				{
					if(iX>-360 && Owe.iX>=240)//����ͼ�ƶ�
					{
						for(i=1;i<=2;i++)
						{
							iX-=1;

							BeginBatchDraw();

							putimage(iX,0,&img);
							getimage(&imgbkNum, Owe.iX, Owe.iY, 30, 40);
							srcDC = GetImageHDC( &imgOwe[1][iFlag++]);
							TransparentBlt(dstDC, Owe.iX,Owe.iY, 30,40, srcDC, 0,0, 30,40,  RGB(0,255,0)); 

							FlushBatchDraw();
							EndBatchDraw();

							if(iFlag>=3) iFlag=0;
						}
					}

					else
					{
						Owe.iX+=2;
						MoveImage(&imgbkNum);
					}
				}
				else
					MoveImage(&imgbkNum);

				break;

			case SPACE:  //�����˵�
				Menu2();
				break;

			default :
				break;
		}
	}

	return HOME;
}
/////////////////////Ұ��ս��1///////////////////
void YeWaiZhanchang_1()
{
	IMAGE img,imgkbNum,imgBall;
	IMAGE imgMenu,imgMenu2[4],imgMenu1;
	IMAGE imgShow,imgShow1[7];
	IMAGE imgNotRun;
	IMAGE imgWin,imgWin1[2];

	struct Pet OtherPet;	
	int   iX=0,iX1=0,iY1;
	int   iPetNum=0;
	int   i,iKey;
	char  cNum[8];
	char  cWord[40]="ս��ʤ����n  ��ϲ�㣡����n  ���";

	HDC dstDC = GetImageHDC();  //��ȡĿ�껷�����
	HDC srcDC ;

	switch(rand()%2)
	{
		case 0:	
			loadimage(&img, "ͼƬ/��ͼ/Ұ��ս��1.bmp");  //���ص�ͼ640*480
			break;
		case 1:
			loadimage(&img, "ͼƬ/��ͼ/Ұ��ս��2.bmp");  //���ص�ͼ640*480
			break;
	}

	loadimage(&imgBall,"ͼƬ/������.bmp",10,10);
	loadimage(&imgShow,"ͼƬ/�������.bmp");
	loadimage(&imgMenu,"ͼƬ/ս���˵�.bmp");
	loadimage(&imgMenu1,"ͼƬ/ѡ���.bmp");
	loadimage(&imgWin,"ͼƬ/ʤ��.bmp");

	SetWorkingImage(&imgWin);
	for(i=0;i<2;i++)
		getimage(&imgWin1[i],0,i*60,180,60);

	SetWorkingImage(&imgShow);
	for(i=0;i<7;i++)
		getimage(&imgShow1[i],i*67,0,67,99);

	SetWorkingImage(&imgMenu1);
	for(i=0;i<4;i++)
		getimage(&imgMenu2[i],i*45,0,45,20);

	SetWorkingImage();

	//������ɾ�����
	OtherPet.iNum=rand()%40;

		
	if(iOpenMusic)
	{
		mciSendString("stop BackMusic1", NULL, 0, NULL);
		mciSendString("stop BackMusic2", NULL, 0, NULL);
		mciSendString("play YuGuai from 0", NULL, 0, NULL);
	}

	AlterScreen();

	if(iOpenMusic)
		mciSendString("play BattleMusic repeat", NULL, 0, NULL); //ѭ������


	BeginBatchDraw();

	putimage(0,0,&img);

	srcDC = GetImageHDC( &imgOwe[1][0]);
	TransparentBlt( dstDC, 90, 210, 30, 40, srcDC, 0, 0, 30, 40,  RGB(0,255,0));

	getimage(&imgkbNum,0,0,640,480);

	srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
	TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
	FlushBatchDraw();

	srcDC = GetImageHDC( &imgBall);

	iX1=90;
	while(TRUE)		//���ƶ�
	{
		if(iX1>=205)	break;
		iX1+=2;

		putimage(0,0,&imgkbNum);
		srcDC = GetImageHDC( &imgBall);
		TransparentBlt( dstDC, iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));
		srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
		TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
		FlushBatchDraw();
		Sleep(8);
	}

	for(i=0;i<7;i++)
	{

		BeginBatchDraw();
		putimage(0,0,&imgkbNum);
		srcDC = GetImageHDC( &imgShow1[i]);
		TransparentBlt( dstDC, 173, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
		srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
		TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));

		FlushBatchDraw();
		Sleep(100);
	}

	for(i=0;i<3;i++)//ѡ���ܹ���������
		if(man.pet[i].iPH)
		{
			iPetNum=i;
			break;
		}

	BeginBatchDraw();//��ʾ����
	putimage(0,0,&imgkbNum);
	srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
	TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
	srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
	TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
	FlushBatchDraw();
	
	//ΪҰ�����鸳ֵ
	i=rand()%3;
	OtherPet.iGrade=man.pet[i].iGrade;

	OtherPet.iGrade -= rand()%2;
	if(OtherPet.iGrade<=0)
		OtherPet.iGrade=2;

	OtherPet.iPH = OtherPet.iAlwayPH=(OtherPet.iGrade-1)*6+24;
	OtherPet.iAtt = (OtherPet.iGrade-1)*3+14;
	OtherPet.iDef = (OtherPet.iGrade-1)*2+9;

	while( TRUE) //ս������
	{
		BeginBatchDraw();

		putimage(0,375,&imgMenu);
		switch( iX)
		{
			case 0:
				putimage(8,409,&imgMenu2[iX]);
				break;
			case 1:
				putimage(62,409,&imgMenu2[iX]);
				break;
			case 2:
				putimage(8,435,&imgMenu2[iX]);
				break;
			case 3:
				putimage(62,435,&imgMenu2[iX]);
				break;
			default :
				break;
		}

		if(man.pet[iPetNum].iPH <= (man.pet[iPetNum].iAlwayPH)/4 ) //HPС�ڵ���1/4ʱ�Ժ�ɫ
			setcolor(RED);
		else
			setcolor(BLACK);

		outtextxy(120,380,cPetName[man.pet[iPetNum].iNum]); //��ʾ������Ϣ
		sprintf(cNum,"%d��",man.pet[iPetNum].iGrade);//�ȼ�
		outtextxy(210,380,cNum);

		sprintf(cNum,"%d",man.pet[iPetNum].iPH);//HP
		outtextxy(165,415,cNum);
		sprintf(cNum,"%d",man.pet[iPetNum].iAlwayPH);
		outtextxy(215,415,cNum);

		sprintf(cNum,"%d",man.pet[iPetNum].iExp);//MP
		outtextxy(165,442,cNum);
		sprintf(cNum,"%d",man.pet[iPetNum].iAlwayExp);
		outtextxy(215,442,cNum);


		setcolor(BLACK);
		//��ʾ���־�����Ϣ
		outtextxy(475,380,cPetName1[OtherPet.iNum]);	//����
		sprintf(cNum,"%d��",OtherPet.iGrade); //�ȼ�
		outtextxy(565,380,cNum);

		sprintf(cNum,"%d",OtherPet.iAlwayPH); //HP
		outtextxy(565,415,cNum);

		sprintf(cNum,"%d",OtherPet.iPH);
		outtextxy(520,415,cNum);	
		FlushBatchDraw();
						
		DeviceKBBuf();
		iKey=getch();

		if(iOpenMusic)
			mciSendString("play Key from 0", NULL, 0, NULL);

		switch( iKey )//ѡ�����
		{
			case UP:
				if(iX+2>=4)
					iX-=2;
				else
					iX+=2;
				break;

			case DOWN:
				if(iX+2>=4)
					iX-=2;
				else
					iX+=2;
				break;

			case LEFT:
				if(iX%2==0)
					iX+=1;
				else
					iX-=1;
				break;

			case RIGHT:
				if(iX%2==0)
					iX+=1;
				else
					iX-=1;
				break;

			case ENTER:
				switch( iX )
				{
					case 0:	//����

						iX1=176;
						for(i=1;i<=10;i++)
						{
							BeginBatchDraw();//������ǰ�ƶ�
							putimage(0,0,&imgkbNum);
							srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
							TransparentBlt( dstDC, iX1, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							
							srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
							TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							FlushBatchDraw();

							iX1+=2;
							Sleep(50);
						}

						if(rand()%10>2)	//������
						{
							KitShow(404, 185);

							for(i=1;i<=10;i++)
							{
								iY1=185;
								if(i%2==0)
									iY1+=4;
								else
									iY1-=4;

								BeginBatchDraw();//����ʱ�Է��������
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
								TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, iY1, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();

								Sleep(50);
							}
							

							if( (man.pet[iPetNum].iAtt-OtherPet.iDef) <=0 )
							{
								OtherPet.iPH-=1;
								sprintf(cNum,"-%d",1);
							}
							else
							{
								OtherPet.iPH-=(man.pet[iPetNum].iAtt-OtherPet.iDef);
								sprintf(cNum,"-%d",(man.pet[iPetNum].iAtt-OtherPet.iDef));
							}

							setcolor(RED);
							outtextxy(400, 200, cNum);	
							FlushBatchDraw();
							Sleep(300);
							setcolor(BLACK);

							man.pet[iPetNum].iExp += OtherPet.iGrade*2;	//��þ���ֵ
							if(man.pet[iPetNum].iExp >= man.pet[iPetNum].iAlwayExp)
								AdvancePet( iPetNum);//�ȼ�����

							if( OtherPet.iPH<=0) //Ұ������HPֵС��0ʱʤ��
							{
								sprintf(cNum,"%4d",OtherPet.iGrade+9); //�����Ӧ���
								strcat(cWord,cNum);
								strcat(cWord,"��ң�����");
								man.iMoney += OtherPet.iGrade+9;

								if(iOpenMusic)
								{	
									mciSendString("stop BattleMusic", NULL, 0, NULL);
									mciSendString("play Win from 0", NULL, 0, NULL);
								}

								Sleep(800);

								srcDC = GetImageHDC( &imgWin1[0]);
								TransparentBlt( dstDC, 230, 210, 180, 60, srcDC, 0, 0, 180, 60,  RGB(0,255,0));
								FlushBatchDraw();
								EndBatchDraw();	

								Road_2(cWord);

								AlterScreen();

								if(iOpenMusic)
									mciSendString("play BackMusic1 repeat", NULL, 0, NULL); //ѭ������

								return ;
							}
						}

						Sleep(500);

				BEGIN2:
						iX1=404;//�Է�����

						for(i=1; i<=10; i++)
						{
							BeginBatchDraw();//Ұ���ƶ�����
							putimage(0,0,&imgkbNum);
							srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
							TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							
							srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
							TransparentBlt( dstDC, iX1, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							FlushBatchDraw();

							iX1 -= 2;
							Sleep(50);
						}

						if( rand()%10>2 ) //�������и���
						{
							KitShow(176, 185);

							for(i=1; i<=10; i++)
							{
								iY1=185;
								if( i%2 == 0)
									iY1 += 4;
								else
									iY1 -= 4;

								BeginBatchDraw(); //�������
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
								TransparentBlt( dstDC, 176, iY1 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();

								Sleep(50);
							}


							if((OtherPet.iAtt-man.pet[iPetNum].iDef) <= 0)
							{
								man.pet[iPetNum].iPH -= 1;
								sprintf(cNum,"-%d",1);
							}
							else 
							{							
								man.pet[iPetNum].iPH -= (OtherPet.iAtt-man.pet[iPetNum].iDef);	
								sprintf(cNum,"-%d", (OtherPet.iAtt-man.pet[iPetNum].iDef));
							}

							setcolor(RED);
							outtextxy(240, 200, cNum);	
							FlushBatchDraw();
							Sleep(300);
							setcolor(BLACK);

							if(man.pet[iPetNum].iPH <= 0)	//����HPֵС��0ʱ�Զ�������������
							{
								man.pet[iPetNum].iPH = 0;

								for(i=0; i<3; i++)	//�Զ�ѡ���ܳ�ս�ľ���
									if( man.pet[i].iPH)
									{
										iPetNum = i;
										iX1 = 90;
						
										while(TRUE)		//���ƶ�
										{
											if(iX1 >= 205)	break;
											iX1 += 2;

											BeginBatchDraw();
											putimage(0,0,&imgkbNum);
											srcDC = GetImageHDC( &imgBall);
											TransparentBlt( dstDC, iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));
											srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
											TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
											FlushBatchDraw();
											Sleep(8);
										}

										for(i=0;i<7;i++)
										{
											BeginBatchDraw();
											putimage(0,0,&imgkbNum);
											srcDC = GetImageHDC( &imgShow1[i]);
											TransparentBlt( dstDC, 173, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
											srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
											TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
											FlushBatchDraw();
											Sleep(100);
										}

										BeginBatchDraw(); //��ʾ����
										putimage(0,0,&imgkbNum);
										srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
										TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
										srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
										TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
										FlushBatchDraw();

										break;
									}

								if(i==3)	//���о���HP��Ϊ0ʱʧ��
								{
									if(iOpenMusic)
									{
										mciSendString("stop BattleMusic", NULL, 0, NULL);
										mciSendString("play Lose from 0", NULL, 0, NULL);
									}

									srcDC = GetImageHDC( &imgWin1[1]);
									TransparentBlt( dstDC, 230, 210, 180, 60, srcDC, 0, 0, 180, 60,  RGB(0,255,0));
									EndBatchDraw();
									Sleep(4000);

									if(iOpenMusic)
									{
										mciSendString("stop Lose",NULL,0,NULL);
										mciSendString("play BackMusic1 repeat", NULL, 0, NULL);
									}
								
									return ;
								}

								continue;
							}
						}

						BeginBatchDraw(); //��ʾ����
						putimage(0,0,&imgkbNum);
						srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
						TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
						
						srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
						TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
						FlushBatchDraw();
						break;

					case 1: //����
						BeiBaoMenu();
						continue;
						break;

					case 2: //�ֶ���������
						i = ChangePet();

						if(i >= 0 && i != iPetNum)	
						{
							iPetNum=i;
							iX1=90;
						
							while( TRUE)		//���ƶ�
							{
								if(iX1 >= 205)	break;
								iX1 += 2;

								BeginBatchDraw();
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgBall);
								TransparentBlt( dstDC, iX1, 230, 10,10, srcDC, 0, 0,10,10,  RGB(0,255,0));
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();
								Sleep(8);
							}

							for(i=0;i<7;i++)
							{
								BeginBatchDraw();
								putimage(0,0,&imgkbNum);
								srcDC = GetImageHDC( &imgShow1[i]);
								TransparentBlt( dstDC, 173, 150, 67,99, srcDC, 0, 0, 67,99,  RGB(0,255,0));
								srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
								TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
								FlushBatchDraw();
								Sleep(100);
							}
	
							BeginBatchDraw();	//��ʾ����
							putimage(0,0,&imgkbNum);
							srcDC = GetImageHDC( &imgPet[man.pet[iPetNum].iNum]);
							TransparentBlt( dstDC, 176, 185 ,84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							srcDC = GetImageHDC( &imgPet1[OtherPet.iNum]);
							TransparentBlt( dstDC, 404, 185, 84, 90, srcDC, 0, 0, 84, 90,  RGB(0,255,0));
							FlushBatchDraw();
							Sleep(500);
	
							goto BEGIN2;
						}
						break;
	
					case 3: //����
						if(rand()%10>5)
						{
							EndBatchDraw();	
							AlterScreen();

							if(iOpenMusic)
							{	
								mciSendString("stop BattleMusic", NULL, 0, NULL);
								mciSendString("play BackMusic1 repeat", NULL, 0, NULL); //ѭ������
							}

							return;
						}
						else
						{
							Sleep(1000);
							goto BEGIN2;
						}

						break;
	
					default :
						break;
				}
	
				    break;

				default :
					break;
			}	
		}

	return;
}

//////////////////////��������////////////////
void AlterScreen()
{
	BeginBatchDraw();
	cleardevice();
	DWORD* pBuffer = GetImageBuffer( );

	for(int j=1;j<100;j++)
	{
		for(int i = 0; i < 640 * 480; i++)
				pBuffer[i] = RGB(GetRValue(pBuffer[i]) -1, GetGValue(pBuffer[i]) -1, GetBValue(pBuffer[i]) - 1);

		FlushBatchDraw();
	}

	for(j=0;j<100;j++)
	{
		for(int i = 0; i < 640 * 480; i++)
				pBuffer[i] = RGB(GetRValue(pBuffer[i]) +1, GetGValue(pBuffer[i]) +1, GetBValue(pBuffer[i]) +1);

		FlushBatchDraw();
	}
	EndBatchDraw();
}
